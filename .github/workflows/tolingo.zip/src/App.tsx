/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Course, LessonModel, NavDestination, UserProfile } from './types';
import { getDefaultCourse } from './data/courseData';
import { INITIAL_USER_PROFILE, INITIAL_MISTAKES, getSampleLeaderboard } from './data/seedData';
import { getStrings } from './localization/strings';
import { audioService } from './services/audio';

import { TopStatsBar } from './components/TopStatsBar';
import { BottomNavBar } from './components/BottomNavBar';
import { HeartRefillDialog } from './components/HeartRefillDialog';
import { GitSyncModal } from './components/GitSyncModal';

import { HomeScreen } from './screens/HomeScreen';
import { LessonScreen } from './screens/LessonScreen';
import { LessonResultScreen } from './screens/LessonResultScreen';
import { MistakesReviewScreen } from './screens/MistakesReviewScreen';
import { LeaderboardScreen } from './screens/LeaderboardScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { OfflineTranslatorScreen } from './screens/OfflineTranslatorScreen';

export default function App() {
  // Course State
  const [course, setCourse] = useState<Course>(getDefaultCourse());
  // User Profile State
  const [userProfile, setUserProfile] = useState<UserProfile>(INITIAL_USER_PROFILE);
  // Mistakes list
  const [mistakes, setMistakes] = useState(INITIAL_MISTAKES);
  // Leaderboard
  const [leaderboard, setLeaderboard] = useState(() => getSampleLeaderboard(INITIAL_USER_PROFILE.xp));

  // Current Screen / Route
  const [currentTab, setCurrentTab] = useState<NavDestination>('LEARN');
  const [activeLessonTarget, setActiveLessonTarget] = useState<{
    unitId: string;
    lesson: LessonModel;
    isSkippingUnit?: boolean;
  } | null>(null);

  // Lesson completion result state
  const [lastLessonResult, setLastLessonResult] = useState<{
    xpGained: number;
    gemsGained: number;
    accuracyPercent: number;
    streakDays: number;
  } | null>(null);

  // Modals
  const [showHeartRefill, setShowHeartRefill] = useState(false);
  const [showGitSync, setShowGitSync] = useState(false);

  // Localization strings
  const strings = getStrings(userProfile.nativeLanguage);

  // Set sound settings whenever changed
  useEffect(() => {
    audioService.setSoundEnabled(userProfile.soundEffectsEnabled);
  }, [userProfile.soundEffectsEnabled]);

  // Handle lesson start
  const handleStartLesson = (unitId: string, lesson: LessonModel, isSkippingUnit = false) => {
    if (userProfile.hearts <= 0) {
      setShowHeartRefill(true);
      return;
    }
    setActiveLessonTarget({ unitId, lesson, isSkippingUnit });
  };

  // Handle lesson completed
  const handleCompleteLesson = (accuracyPercent: number) => {
    if (!activeLessonTarget) return;

    const { unitId, lesson, isSkippingUnit } = activeLessonTarget;
    const xpReward = isSkippingUnit ? lesson.xpReward + 50 : lesson.xpReward;
    const gemReward = isSkippingUnit ? lesson.gemReward + 20 : lesson.gemReward;

    // Update course units
    setCourse((prevCourse) => {
      const allUnits = prevCourse.units;
      const unitIndex = allUnits.findIndex((u) => u.id === unitId);
      const currentUnit = allUnits[unitIndex];
      const isExam = lesson.isExam;

      const updatedUnits = allUnits.map((u, uIdx) => {
        if (uIdx === unitIndex) {
          if (isSkippingUnit) {
            // Completed unit exam in skip mode: mark ALL lessons in unit completed!
            return {
              ...u,
              lessons: u.lessons.map((l) => ({ ...l, isCompleted: true, isLocked: false })),
            };
          } else {
            // Standard progress
            const allLessonIds = u.lessons.map((l) => l.id);
            const currIdx = allLessonIds.indexOf(lesson.id);
            const nextId = allLessonIds[currIdx + 1];

            return {
              ...u,
              lessons: u.lessons.map((l) => {
                if (l.id === lesson.id) {
                  return { ...l, isCompleted: true, isLocked: false };
                }
                if (!isExam && l.id === nextId) {
                  return { ...l, isLocked: false };
                }
                return l;
              }),
            };
          }
        } else if (uIdx === unitIndex + 1 && (isExam || isSkippingUnit)) {
          // Passing unit exam unlocks first lesson of next unit
          return {
            ...u,
            lessons: u.lessons.map((l) => (l.lessonNumber === 1 ? { ...l, isLocked: false } : l)),
          };
        }
        return u;
      });

      return { ...prevCourse, units: updatedUnits };
    });

    // Update user profile stats & reset lastStudyTimestamp
    setUserProfile((prev) => {
      const newXp = prev.xp + xpReward;
      const newGems = prev.gems + gemReward;
      const newCompleted = prev.completedLessonsCount + (isSkippingUnit ? 3 : 1);
      const newWords = prev.totalWordsLearned + 8;

      return {
        ...prev,
        xp: newXp,
        gems: newGems,
        completedLessonsCount: newCompleted,
        totalWordsLearned: newWords,
        streakActiveToday: true,
        lastStudyTimestamp: Date.now(),
      };
    });

    // Refresh leaderboard
    setLeaderboard(getSampleLeaderboard(userProfile.xp + xpReward));

    // Show result celebration screen
    setLastLessonResult({
      xpGained: xpReward,
      gemsGained: gemReward,
      accuracyPercent,
      streakDays: userProfile.streakDays,
    });
    setActiveLessonTarget(null);
  };

  const handleLoseHeart = () => {
    setUserProfile((prev) => ({
      ...prev,
      hearts: Math.max(0, prev.hearts - 1),
    }));
  };

  const handleLogMistake = (exercise: { id: string; question: string; promptTranslation?: string; correctAnswer: string }, userAnswer: string) => {
    const newMistake = {
      id: `mistake_${Date.now()}`,
      exerciseId: exercise.id,
      question: exercise.question,
      promptTranslation: exercise.promptTranslation || '',
      correctAnswer: exercise.correctAnswer,
      userAnswer,
      timestamp: Date.now(),
    };
    setMistakes((prev) => [newMistake, ...prev.filter((m) => m.question !== exercise.question)]);
  };

  const handleResolveMistake = (mistakeId: string) => {
    setMistakes((prev) => prev.filter((m) => m.id !== mistakeId));
    setUserProfile((prev) => ({
      ...prev,
      hearts: Math.min(prev.maxHearts, prev.hearts + 1),
      xp: prev.xp + 5,
      lastStudyTimestamp: Date.now(),
    }));
  };

  const handleRefillWithGems = () => {
    if (userProfile.gems >= 50) {
      setUserProfile((prev) => ({
        ...prev,
        gems: prev.gems - 50,
        hearts: prev.maxHearts,
      }));
      audioService.playChestRewardSound();
      setShowHeartRefill(false);
    }
  };

  const handleClaimChest = (unitId: string) => {
    let bonus = 30;
    setCourse((prev) => ({
      ...prev,
      units: prev.units.map((u) => {
        if (u.id === unitId) {
          bonus = u.bonusGems;
          return { ...u, bonusChestClaimed: true };
        }
        return u;
      }),
    }));
    setUserProfile((prev) => ({
      ...prev,
      gems: prev.gems + bonus,
      xp: prev.xp + 25,
      lastStudyTimestamp: Date.now(),
    }));
    audioService.playChestRewardSound();
  };

  return (
    <div
      dir={userProfile.nativeLanguage === 'ar' ? 'rtl' : 'ltr'}
      className="min-h-screen bg-[#131F24] text-[#E5E5E5] font-['Tajawal','Nunito',sans-serif]"
    >
      {/* 1. Active Lesson Mode */}
      {activeLessonTarget ? (
        <LessonScreen
          lesson={activeLessonTarget.lesson}
          hearts={userProfile.hearts}
          strings={strings}
          onCompleteLesson={handleCompleteLesson}
          onLoseHeart={handleLoseHeart}
          onLogMistake={handleLogMistake}
          onQuitLesson={() => setActiveLessonTarget(null)}
        />
      ) : lastLessonResult ? (
        /* 2. Lesson Result Mode */
        <LessonResultScreen
          xpGained={lastLessonResult.xpGained}
          gemsGained={lastLessonResult.gemsGained}
          accuracyPercent={lastLessonResult.accuracyPercent}
          streakDays={lastLessonResult.streakDays}
          strings={strings}
          onContinue={() => setLastLessonResult(null)}
        />
      ) : (
        /* 3. Main Shell (Top Bar + Body + Bottom Nav) */
        <div className="flex flex-col min-h-screen">
          <TopStatsBar
            userProfile={userProfile}
            course={course}
            strings={strings}
            onOpenHeartRefill={() => setShowHeartRefill(true)}
            onOpenGitSync={() => setShowGitSync(true)}
            onChangeLanguage={(code) =>
              setUserProfile((prev) => ({ ...prev, nativeLanguage: code }))
            }
          />

          <main className="flex-1">
            {currentTab === 'LEARN' && (
              <HomeScreen
                course={course}
                strings={strings}
                mistakesCount={mistakes.length}
                onStartLesson={handleStartLesson}
                onOpenMistakes={() => setCurrentTab('MISTAKES')}
                onClaimChest={handleClaimChest}
                onOpenTranslator={() => setCurrentTab('TRANSLATE')}
              />
            )}

            {currentTab === 'TRANSLATE' && (
              <OfflineTranslatorScreen onBackToLearn={() => setCurrentTab('LEARN')} />
            )}

            {currentTab === 'MISTAKES' && (
              <MistakesReviewScreen
                mistakes={mistakes}
                strings={strings}
                onResolveMistake={handleResolveMistake}
              />
            )}

            {currentTab === 'LEADERBOARD' && (
              <LeaderboardScreen
                currentLeague={userProfile.currentLeague}
                leaderboardEntries={leaderboard}
                strings={strings}
              />
            )}

            {currentTab === 'PROFILE' && (
              <ProfileScreen
                userProfile={userProfile}
                strings={strings}
                onLanguageSelected={(lang) =>
                  setUserProfile((prev) => ({ ...prev, nativeLanguage: lang }))
                }
                onDailyGoalSelected={(mins) =>
                  setUserProfile((prev) => ({ ...prev, dailyGoalMinutes: mins }))
                }
                onToggleSound={(enabled) =>
                  setUserProfile((prev) => ({ ...prev, soundEffectsEnabled: enabled }))
                }
                onToggleHaptic={(enabled) =>
                  setUserProfile((prev) => ({ ...prev, hapticEnabled: enabled }))
                }
                onToggleDarkMode={(enabled) =>
                  setUserProfile((prev) => ({ ...prev, darkMode: enabled }))
                }
                onOpenGitSync={() => setShowGitSync(true)}
              />
            )}
          </main>

          <BottomNavBar
            currentTab={currentTab}
            onSelectTab={setCurrentTab}
            mistakesCount={mistakes.length}
            strings={strings}
          />
        </div>
      )}

      {/* Heart Refill Modal */}
      {showHeartRefill && (
        <HeartRefillDialog
          userProfile={userProfile}
          strings={strings}
          onDismiss={() => setShowHeartRefill(false)}
          onRefillWithGems={handleRefillWithGems}
          onPracticeToEarnHeart={() => {
            setShowHeartRefill(false);
            setCurrentTab('MISTAKES');
          }}
        />
      )}

      {/* GitHub Sync Modal */}
      {showGitSync && (
        <GitSyncModal strings={strings} onClose={() => setShowGitSync(false)} />
      )}
    </div>
  );
}
