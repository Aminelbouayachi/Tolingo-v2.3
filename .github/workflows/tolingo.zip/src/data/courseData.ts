import { Course, Exercise, ExerciseType, LessonModel, LessonNodeType, UnitModel } from '../types';

interface Topic {
  title: string;
  description: string;
  words: string[];
  phrases: string[];
}

interface Entry {
  en: string;
  ar: string;
}

function parseEntry(raw: string): Entry {
  const parts = raw.split('|');
  return {
    en: (parts[0] || '').trim(),
    ar: (parts[1] || '').trim(),
  };
}

// Simple seeded PRNG for reproducible exercise generation
class SeededRandom {
  private seed: number;
  constructor(seed: number) {
    this.seed = seed;
  }
  next(): number {
    this.seed = (this.seed * 9301 + 49297) % 233280;
    return this.seed / 233280;
  }
  shuffle<T>(array: T[]): T[] {
    const copy = [...array];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }
}

function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

const TOPICS: Topic[] = [
  {
    title: 'Greetings & Basics',
    description: 'Say hello, goodbye and be polite.',
    words: [
      'Hello|مرحباً', 'Goodbye|مع السلامة', 'Please|من فضلك', 'Thank you|شكراً', 'Sorry|آسف',
      'Yes|نعم', 'No|لا', 'Friend|صديق', 'Morning|صباح', 'Night|ليل'
    ],
    phrases: [
      'How are you?|كيف حالك؟', 'I am fine|أنا بخير',
      'My name is Sarah|اسمي سارة', 'Nice to meet you|سررت بلقائك'
    ]
  },
  {
    title: 'Family',
    description: 'Talk about the people you love.',
    words: [
      'Mother|أم', 'Father|أب', 'Brother|أخ', 'Sister|أخت', 'Son|ابن',
      'Daughter|ابنة', 'Grandfather|جد', 'Grandmother|جدة', 'Uncle|عم', 'Family|عائلة'
    ],
    phrases: [
      'This is my family|هذه عائلتي', 'I love my mother|أحب أمي',
      'He is my brother|هو أخي', 'She is my sister|هي أختي'
    ]
  },
  {
    title: 'Numbers',
    description: 'Count from one to ten.',
    words: [
      'One|واحد', 'Two|اثنان', 'Three|ثلاثة', 'Four|أربعة', 'Five|خمسة',
      'Six|ستة', 'Seven|سبعة', 'Eight|ثمانية', 'Nine|تسعة', 'Ten|عشرة'
    ],
    phrases: [
      'I have two brothers|لدي أخوان', 'I have three books|لدي ثلاثة كتب',
      'There are five apples|هناك خمس تفاحات', 'I need four chairs|أحتاج أربعة كراسي'
    ]
  },
  {
    title: 'Colors',
    description: 'Describe the world around you.',
    words: [
      'Red|أحمر', 'Blue|أزرق', 'Green|أخضر', 'Yellow|أصفر', 'Black|أسود',
      'White|أبيض', 'Orange|برتقالي', 'Purple|بنفسجي', 'Pink|وردي', 'Brown|بني'
    ],
    phrases: [
      'The sky is blue|السماء زرقاء', 'I like the red car|أحب السيارة الحمراء',
      'The cat is black|القطة سوداء', 'The grass is green|العشب أخضر'
    ]
  },
  {
    title: 'Food & Drinks',
    description: 'Name what you eat and drink every day.',
    words: [
      'Water|ماء', 'Bread|خبز', 'Milk|حليب', 'Apple|تفاحة', 'Rice|أرز',
      'Chicken|دجاج', 'Fish|سمك', 'Egg|بيضة', 'Cheese|جبن', 'Salad|سلطة'
    ],
    phrases: [
      'I eat bread|أنا آكل الخبز', 'I drink water|أنا أشرب الماء',
      'She likes fish|هي تحب السمك', 'We eat rice|نحن نأكل الأرز'
    ]
  },
  {
    title: 'تواصل في العمل (Communicate at Work)',
    description: 'Speak with colleagues, attend meetings, and email clients.',
    words: [
      'Office|مكتب', 'Meeting|اجتماع', 'Email|بريد إلكتروني', 'Boss|مدير', 'Project|مشروع',
      'Work|عمل', 'Colleague|زميل', 'Presentation|عرض تقديمي', 'Report|تقرير', 'Deadline|الموعد النهائي'
    ],
    phrases: [
      'I am working on the project|أنا أعمل على المشروع', 'Let us have a meeting|دعنا نعقد اجتماعاً',
      'She sent an important email|أرسلت بريداً إلكترونياً هاماً', 'The report is ready|التقرير جاهز'
    ]
  },
  {
    title: 'Animals',
    description: 'Meet animals from the farm and the wild.',
    words: [
      'Cat|قطة', 'Dog|كلب', 'Bird|طائر', 'Horse|حصان', 'Cow|بقرة',
      'Lion|أسد', 'Rabbit|أرنب', 'Camel|جمل', 'Sheep|خروف', 'Monkey|قرد'
    ],
    phrases: [
      'The dog is big|الكلب كبير', 'I have a cat|لدي قطة',
      'The bird can fly|يستطيع الطائر الطيران', 'Lions are strong|الأسود قوية'
    ]
  },
  {
    title: 'Home',
    description: 'Talk about your house and rooms.',
    words: [
      'House|منزل', 'Door|باب', 'Window|نافذة', 'Kitchen|مطبخ', 'Bedroom|غرفة نوم',
      'Bed|سرير', 'Chair|كرسي', 'Garden|حديقة', 'Key|مفتاح', 'Roof|سقف'
    ],
    phrases: [
      'This is my house|هذا منزلي', 'Open the door|افتح الباب',
      'The kitchen is clean|المطبخ نظيف', 'I am in the garden|أنا في الحديقة'
    ]
  },
  {
    title: 'Body & Health',
    description: 'Explain how you feel to a doctor.',
    words: [
      'Head|رأس', 'Eye|عين', 'Ear|أذن', 'Nose|أنف', 'Mouth|فم',
      'Hand|يد', 'Leg|ساق', 'Heart|قلب', 'Doctor|طبيب', 'Hospital|مستشفى'
    ],
    phrases: [
      'My head hurts|رأسي يؤلمني', 'I need a doctor|أحتاج إلى طبيب',
      'Wash your hands|اغسل يديك', 'She has beautiful eyes|لديها عينان جميلتان'
    ]
  },
  {
    title: 'Clothes',
    description: 'Describe what you wear.',
    words: [
      'Shirt|قميص', 'Pants|بنطال', 'Shoes|حذاء', 'Hat|قبعة', 'Dress|فستان',
      'Jacket|سترة', 'Socks|جوارب', 'Scarf|وشاح', 'Belt|حزام', 'Glasses|نظارات'
    ],
    phrases: [
      'I wear a blue shirt|أرتدي قميصاً أزرق', 'The shoes are new|الحذاء جديد',
      'She wears a red dress|هي ترتدي فستاناً أحمر', 'Take your jacket|خذ سترتك'
    ]
  },
  {
    title: 'Travel & Directions',
    description: 'Find your way around the city.',
    words: [
      'Airport|مطار', 'Ticket|تذكرة', 'Passport|جواز سفر', 'Taxi|سيارة أجرة', 'Hotel|فندق',
      'Train|قطار', 'Street|شارع', 'Map|خريطة', 'Left|يسار', 'Right|يمين'
    ],
    phrases: [
      'Where is the airport?|أين المطار؟', 'I need a taxi|أحتاج إلى سيارة أجرة',
      'Turn left|انعطف يساراً', 'I have a ticket|لدي تذكرة'
    ]
  },
  {
    title: 'Time & Days',
    description: 'Talk about days, weeks and hours.',
    words: [
      'Today|اليوم', 'Tomorrow|غداً', 'Yesterday|أمس', 'Monday|الاثنين', 'Friday|الجمعة',
      'Week|أسبوع', 'Month|شهر', 'Year|سنة', 'Hour|ساعة', 'Minute|دقيقة'
    ],
    phrases: [
      'See you tomorrow|أراك غداً', 'What time is it?|كم الساعة؟',
      'Today is Friday|اليوم هو الجمعة', 'I work every day|أعمل كل يوم'
    ]
  },
  {
    title: 'Weather & Nature',
    description: 'Describe the weather and nature.',
    words: [
      'Sun|شمس', 'Rain|مطر', 'Wind|ريح', 'Snow|ثلج', 'Cloud|غيمة',
      'Hot|حار', 'Cold|بارد', 'Sea|بحر', 'Mountain|جبل', 'Tree|شجرة'
    ],
    phrases: [
      'It is hot today|الجو حار اليوم', 'I like the rain|أحب المطر',
      'The sea is beautiful|البحر جميل', 'The mountain is high|الجبل عال'
    ]
  },
  {
    title: 'School & Work',
    description: 'Talk about study and your job.',
    words: [
      'School|مدرسة', 'Teacher|معلم', 'Student|طالب', 'Book|كتاب', 'Pen|قلم',
      'Office|مكتب', 'Computer|حاسوب', 'Job|وظيفة', 'Lesson|درس', 'Exam|امتحان'
    ],
    phrases: [
      'I am a student|أنا طالب', 'The teacher is kind|المعلم لطيف',
      'I go to school|أذهب إلى المدرسة', 'I study English|أدرس الإنجليزية'
    ]
  },
  {
    title: 'Shopping',
    description: 'Buy things and ask about prices.',
    words: [
      'Shop|متجر', 'Market|سوق', 'Money|مال', 'Price|سعر', 'Cheap|رخيص',
      'Expensive|غالٍ', 'Bag|حقيبة', 'Size|مقاس', 'Discount|خصم', 'Card|بطاقة'
    ],
    phrases: [
      'How much is this?|بكم هذا؟', 'It is too expensive|إنه غالٍ جداً',
      'I want a bag|أريد حقيبة', 'Do you have a discount?|هل لديكم خصم؟'
    ]
  },
  {
    title: 'Technology & Internet',
    description: 'Use your smartphone, apps and computers.',
    words: [
      'Phone|هاتف', 'App|تطبيق', 'Internet|إنترنت', 'Password|كلمة المرور', 'Message|رسالة',
      'Screen|شاشة', 'Website|موقع إلكتروني', 'Email|بريد إلكتروني', 'Video|فيديو', 'Online|متصل'
    ],
    phrases: [
      'Send me a message|أرسل لي رسالة', 'Check your email|تحقق من بريدك',
      'I use this app|أستخدم هذا التطبيق', 'The internet is fast|الإنترنت سريع'
    ]
  },
  {
    title: 'Emotions & Feelings',
    description: 'Express how you feel every day.',
    words: [
      'Happy|سعيد', 'Sad|حزين', 'Tired|متعب', 'Angry|غاضب', 'Excited|متحمس',
      'Calm|هادئ', 'Proud|فخور', 'Nervous|متوتر', 'Surprised|متفاجئ', 'Confident|واثق'
    ],
    phrases: [
      'I am very happy|أنا سعيد جداً', 'Are you tired?|هل أنت متعب؟',
      'I feel confident|أشعر بالثقة', 'Do not be nervous|لا تتوتر'
    ]
  },
  {
    title: 'Hobbies & Sports',
    description: 'Talk about what you love doing in free time.',
    words: [
      'Football|كرة القدم', 'Swimming|سباحة', 'Reading|قراءة', 'Music|موسيقى', 'Running|جري',
      'Cooking|طبخ', 'Painting|رسم', 'Gaming|ألعاب', 'Dancing|رقص', 'Sport|رياضة'
    ],
    phrases: [
      'I love playing football|أحب لعب كرة القدم', 'She likes reading books|هي تحب قراءة الكتب',
      'Swimming is good for health|السباحة مفيدة للصحة', 'I listen to music|أستمع إلى الموسيقى'
    ]
  },
  {
    title: 'In the Restaurant',
    description: 'Order delicious food like a native speaker.',
    words: [
      'Menu|قائمة', 'Chef|طاهٍ', 'Delicious|لذيذ', 'Spicy|حار', 'Sweet|حلو',
      'Salad|سلطة', 'Soup|حساء', 'Steak|شريحة لحم', 'Dessert|حلوى', 'Bill|فاتورة'
    ],
    phrases: [
      'The food is delicious|الطعام لذيذ', 'Can I have the menu?|هل يمكنني رؤية القائمة؟',
      'I prefer spicy food|أفضل الطعام الحار', 'Bring the bill please|أحضر الفاتورة من فضلك'
    ]
  },
  {
    title: 'Airport & Flights',
    description: 'Navigate passport control and flight boarding.',
    words: [
      'Flight|رحلة جوية', 'Gate|بوابة', 'Luggage|أمتعة', 'Passport|جواز سفر', 'Seat|مقعد',
      'Customs|جمارك', 'Delay|تأخير', 'Departure|مغادرة', 'Arrival|وصول', 'Boarding|صعود'
    ],
    phrases: [
      'Where is gate four?|أين البوابة رقم أربعة؟', 'Show your passport|أظهر جواز سفرك',
      'My flight is on time|رحلتي في موعدها', 'Here is my luggage|ها هي أمتعتي'
    ]
  },
  {
    title: 'Daily Routine',
    description: 'Describe habits from morning to bedtime.',
    words: [
      'Morning|صباح', 'Breakfast|فطور', 'Shower|استحمام', 'Brush|فرشاة', 'Walk|مشي',
      'Lunch|غداء', 'Dinner|عشاء', 'Sleep|نوم', 'Exercise|تمرين', 'Relax|استرخاء'
    ],
    phrases: [
      'I wake up early|أستيقظ مبكراً', 'I take a shower|آخذ حماماً',
      'I eat breakfast at eight|أتناول الفطور في الثامنة', 'I go to sleep at night|أذهب للنوم ليلاً'
    ]
  },
  {
    title: 'Business & Career',
    description: 'Succeed in meetings, presentations and jobs.',
    words: [
      'Meeting|اجتماع', 'Project|مشروع', 'Client|عميل', 'Contract|عقد', 'Goal|هدف',
      'Team|فريق', 'Success|نجاح', 'Deadline|موعد نهائي', 'Salary|راتب', 'Company|شركة'
    ],
    phrases: [
      'We have a meeting|لدينا اجتماع', 'The project is successful|المشروع ناجح',
      'She is a great manager|هي مديرة بارعة', 'We achieved our goal|حققنا هدفنا بنجاح'
    ]
  },
  {
    title: 'Nature & Environment',
    description: 'Protect the earth and explore natural wonders.',
    words: [
      'Earth|كوكب الأرض', 'Planet|كوكب', 'Forest|غابة', 'Ocean|محيط', 'River|نهر',
      'Energy|طاقة', 'Recycle|تدوير', 'Clean|نظيف', 'Pollution|تلوث', 'Protect|حماية'
    ],
    phrases: [
      'Protect our planet|احمِ كوكبنا', 'The forest is green|الغابة خضراء',
      'The ocean is deep|المحيط عميق', 'Save energy|وفّر الطاقة'
    ]
  },
  {
    title: 'Idioms & Fluency',
    description: 'Speak like a native with common idioms.',
    words: [
      'Piece of cake|سهل جداً', 'Break a leg|حظاً موفقاً', 'Hit the books|اجتهد بالدراسة',
      'Under the weather|متوعك قليلاً', 'Spill the beans|أفشِ السر',
      'See eye to eye|اتفق تماماً', 'Better late than never|أن تأتي متأخراً خير من ألا تأتي',
      'Cost an arm and a leg|باهظ الثمن جداً', 'Time flies|الوقت يمر سريعاً', 'No pain no gain|لا نجاح دون تعب'
    ],
    phrases: [
      'English is a piece of cake|الإنجليزية سهلة جداً',
      'Time flies when you learn|الوقت يمر سريعاً وأنت تتعلم',
      'No pain no gain|لا نجاح دون جهد',
      'Better late than never|أن تبدأ متأخراً خير من ألا تبدأ أبداً'
    ]
  }
];

const LESSON_TITLES = [
  'Meet the words',
  'Practice time',
  'Listen & speak',
  'Build sentences',
  'Unit challenge'
];

function buildMultipleChoice(
  id: string,
  target: Entry,
  pool: Entry[],
  arabicPrompt: boolean,
  rnd: SeededRandom
): Exercise {
  const others = rnd.shuffle(pool.filter((e) => e.en !== target.en)).slice(0, 3);
  if (arabicPrompt) {
    const options = rnd.shuffle([...others.map((e) => e.en), target.en]);
    return {
      id,
      type: 'MULTIPLE_CHOICE',
      question: target.ar,
      promptTranslation: 'اختر المعنى الإنجليزي الصحيح',
      options,
      correctAnswer: target.en,
      audioText: target.en,
    };
  } else {
    const options = rnd.shuffle([...others.map((e) => e.ar), target.ar]);
    return {
      id,
      type: 'MULTIPLE_CHOICE',
      question: target.en,
      promptTranslation: 'اختر المعنى العربي الصحيح',
      options,
      correctAnswer: target.ar,
      audioText: target.en,
    };
  }
}

function buildListening(id: string, target: Entry, pool: Entry[], rnd: SeededRandom): Exercise {
  const others = rnd.shuffle(pool.filter((e) => e.en !== target.en)).slice(0, 3);
  const options = rnd.shuffle([...others.map((e) => e.en), target.en]);
  return {
    id,
    type: 'LISTENING',
    question: 'استمع بدقة واختر الكلمة المنطوقة',
    promptTranslation: target.ar,
    options,
    correctAnswer: target.en,
    audioText: target.en,
  };
}

function buildMatchPairs(id: string, items: Entry[], rnd: SeededRandom): Exercise {
  const shuffled = rnd.shuffle(items);
  const pairs: [string, string][] = shuffled.map((i) => [i.en, i.ar]);
  return {
    id,
    type: 'MATCH_PAIRS',
    question: 'طابق الكلمات الإنجليزية مع معانيها بالعربية',
    matchPairs: pairs,
    correctAnswer: 'matched',
  };
}

function buildArrange(
  id: string,
  phrase: Entry,
  allPhrases: Entry[],
  rnd: SeededRandom,
  translate: boolean
): Exercise {
  const targetWords = phrase.en.split(' ');
  const lowerTarget = targetWords.map((w) => w.toLowerCase());
  const distractorWords = allPhrases
    .filter((p) => p.en !== phrase.en)
    .flatMap((p) => p.en.split(' '))
    .filter((w) => !lowerTarget.includes(w.toLowerCase()));

  const uniqueDistractors = Array.from(new Set(distractorWords.map((w) => w.toLowerCase())))
    .map((lw) => distractorWords.find((w) => w.toLowerCase() === lw) || lw);

  const pickedDistractors = rnd.shuffle(uniqueDistractors).slice(0, 2);
  const bank = rnd.shuffle([...targetWords, ...pickedDistractors]);

  return {
    id,
    type: translate ? 'TRANSLATE_SENTENCE' : 'ARRANGE_WORDS',
    question: phrase.ar,
    promptTranslation: translate ? 'ترجم إلى الإنجليزية' : 'رتب الكلمات الإنجليزية بالترتيب الصحيح',
    targetWords,
    options: bank,
    correctAnswer: phrase.en,
    audioText: phrase.en,
  };
}

function buildSpeaking(id: string, phrase: Entry): Exercise {
  return {
    id,
    type: 'SPEAKING',
    question: phrase.en,
    promptTranslation: phrase.ar,
    correctAnswer: phrase.en,
    audioText: phrase.en,
  };
}

export function buildCourseUnits(): UnitModel[] {
  return TOPICS.map((topic, index) => {
    const unitNumber = index + 1;
    const unitId = `unit_${unitNumber}`;
    const words = topic.words.map(parseEntry);
    const phrases = topic.phrases.map(parseEntry);

    const lessons: LessonModel[] = [];

    // 4 standard lessons per unit
    for (let k = 0; k < 4; k++) {
      const lessonId = `u${unitNumber}_l${k + 1}`;
      const rnd = new SeededRandom(hashCode(lessonId));
      const exercises: Exercise[] = [];

      const nextId = () => `${lessonId}_ex${exercises.length + 1}`;
      const chunk = words.slice(k * 2, k * 2 + 5);
      const safeChunk = chunk.length >= 5 ? chunk : words.slice(0, 5);

      const phrase = phrases[k % phrases.length];
      const nextPhrase = phrases[(k + 1) % phrases.length];

      exercises.push(buildMultipleChoice(nextId(), safeChunk[0], words, true, rnd));
      exercises.push(buildMultipleChoice(nextId(), safeChunk[1], words, false, rnd));
      exercises.push(buildListening(nextId(), safeChunk[2], words, rnd));
      exercises.push(buildMultipleChoice(nextId(), safeChunk[3], words, true, rnd));
      exercises.push(buildMatchPairs(nextId(), safeChunk, rnd));
      exercises.push(buildListening(nextId(), safeChunk[4], words, rnd));
      exercises.push(buildMultipleChoice(nextId(), safeChunk[0], words, false, rnd));
      exercises.push(buildArrange(nextId(), phrase, phrases, rnd, false));
      exercises.push(buildSpeaking(nextId(), phrase));
      exercises.push(buildMultipleChoice(nextId(), safeChunk[2], words, true, rnd));
      exercises.push(buildArrange(nextId(), nextPhrase, phrases, rnd, true));
      exercises.push(buildMultipleChoice(nextId(), safeChunk[4], words, false, rnd));

      const nodeType: LessonNodeType =
        k === 0 ? 'STAR' : k === 1 ? 'LISTENING' : k === 2 ? 'PRACTICE' : 'STORY';

      lessons.push({
        id: lessonId,
        unitId,
        lessonNumber: k + 1,
        title: LESSON_TITLES[k],
        isCompleted: unitNumber === 1 && k === 0, // First lesson already finished for preview demo
        isLocked: !(unitNumber === 1 && (k === 0 || k === 1)),
        isExam: false,
        nodeType,
        exercises,
        xpReward: 15,
        gemReward: 10,
      });
    }

    // Challenge / Exam lesson
    const challengeId = `u${unitNumber}_l5`;
    const rndExam = new SeededRandom(hashCode(challengeId));
    const challengeExercises: Exercise[] = [];
    const cid = () => `${challengeId}_ex${challengeExercises.length + 1}`;
    const shuffledWords = rndExam.shuffle(words);

    shuffledWords.slice(0, 4).forEach((w, i) => {
      challengeExercises.push(buildMultipleChoice(cid(), w, words, i % 2 === 0, rndExam));
    });
    challengeExercises.push(buildListening(cid(), shuffledWords[4] || words[0], words, rndExam));
    challengeExercises.push(buildMatchPairs(cid(), words.slice(0, 5), rndExam));
    phrases.slice(0, 2).forEach((p, i) => {
      challengeExercises.push(buildArrange(cid(), p, phrases, rndExam, i % 2 === 1));
    });
    challengeExercises.push(buildSpeaking(cid(), phrases[0]));
    challengeExercises.push(buildMultipleChoice(cid(), shuffledWords[5] || words[1], words, false, rndExam));

    lessons.push({
      id: challengeId,
      unitId,
      lessonNumber: 5,
      title: `امتحان الترقية للمستوى ${unitNumber + 1} 🏆`,
      isCompleted: false,
      isLocked: true,
      isExam: true,
      nodeType: 'EXAM',
      exercises: challengeExercises,
      xpReward: 50,
      gemReward: 30,
    });

    const sectionNumber = Math.floor((unitNumber - 1) / 5) + 1;
    let sectionTitle = 'الأساسيات والبدايات';
    switch (sectionNumber) {
      case 1:
        sectionTitle = 'الأساسيات والبدايات';
        break;
      case 2:
        sectionTitle = 'تواصل في العمل والحياة اليومية';
        break;
      case 3:
        sectionTitle = 'السفر والمواقف الحية';
        break;
      case 4:
        sectionTitle = 'الطلاقة المهنية المتقدمة';
        break;
      default:
        sectionTitle = 'الإتقان اللانهائي والتحديث اليومي';
        break;
    }

    let grammarTip = 'استخدم الزمن المضارع للمشاعر والتعبير عن النفس';
    switch (unitNumber) {
      case 1:
        grammarTip = 'استخدم ضمائر الفاعل I و You و We في الجمل';
        break;
      case 2:
        grammarTip = 'استخدم صفات الملكية my و your مع أفراد العائلة';
        break;
      case 3:
        grammarTip = 'الأرقام وحساب الكميات في الإنجليزية';
        break;
      case 4:
        grammarTip = 'ترتيب الصفات قبل الأسماء في الجملة';
        break;
      case 5:
        grammarTip = 'أدوات الربط البسيطة and و but';
        break;
      case 6:
        grammarTip = 'استخدم الزمن المضارع للمشاعر';
        break;
      case 7:
        grammarTip = 'أسماء الجمع المنتظمة وغير المنتظمة';
        break;
      case 8:
        grammarTip = 'حروف الجر في المكان والزمان in, on, at';
        break;
      default:
        grammarTip = 'استخدم الزمن المضارع للمشاعر والتعبير عن النفس';
        break;
    }

    return {
      id: unitId,
      unitNumber,
      title: `Unit ${unitNumber}: ${topic.title}`,
      description: topic.description,
      sectionNumber,
      sectionTitle,
      grammarTip,
      lessons,
      bonusChestClaimed: false,
      bonusGems: 30,
    };
  });
}

export function getDefaultCourse(): Course {
  return {
    id: 'en_for_ar',
    title: 'English for Arabic Speakers',
    targetLanguage: 'English',
    sourceLanguage: 'العربية',
    flag: '🇬🇧',
    units: buildCourseUnits(),
  };
}
