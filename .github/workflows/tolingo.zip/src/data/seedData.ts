import { LeaderboardEntry, MistakeItem, UserProfile } from '../types';

export const INITIAL_USER_PROFILE: UserProfile = {
  name: 'Learner',
  email: 'learner@tolingo.app',
  avatarEmoji: '🦊',
  nativeLanguage: 'ar',
  currentCourseId: 'en_for_ar',
  dailyGoalMinutes: 10,
  xp: 120,
  streakDays: 4,
  streakActiveToday: true,
  hearts: 5,
  maxHearts: 5,
  gems: 240,
  currentLeague: 'SILVER',
  leagueRank: 3,
  totalWordsLearned: 68,
  completedLessonsCount: 4,
  totalAccuracyPercent: 94,
  activityDaysThisWeek: [1, 2, 3, 4], // Mon, Tue, Wed, Thu
  soundEffectsEnabled: true,
  hapticEnabled: true,
  darkMode: true,
  reminderHour: 19,
  reminderMinute: 0,
  reminderEnabled: true,
  isOnboarded: true,
};

export const INITIAL_MISTAKES: MistakeItem[] = [
  {
    id: 'mistake_seed_1',
    exerciseId: 'u1_l1_ex1',
    question: 'Hello',
    promptTranslation: 'مرحباً',
    correctAnswer: 'Hello',
    userAnswer: 'Goodbye',
    timestamp: Date.now() - 3600000,
  },
  {
    id: 'mistake_seed_2',
    exerciseId: 'u1_l2_ex1',
    question: 'أنا اسمي سارة',
    promptTranslation: 'Arrange the words in English',
    correctAnswer: 'My name is Sarah',
    userAnswer: 'Sarah is name My',
    timestamp: Date.now() - 7200000,
  },
];

export function getSampleLeaderboard(currentUserXp: number): LeaderboardEntry[] {
  const list: LeaderboardEntry[] = [
    { id: '1', name: 'Karim Z.', avatarEmoji: '🦁', xp: 340, rank: 1, isPromotionZone: true },
    { id: '2', name: 'Amina B.', avatarEmoji: '🌸', xp: 295, rank: 2, isPromotionZone: true },
    {
      id: 'user',
      name: 'You (أنت)',
      avatarEmoji: '🦊',
      xp: currentUserXp,
      isCurrentUser: true,
      rank: 3,
      isPromotionZone: true,
    },
    { id: '3', name: 'Youssef M.', avatarEmoji: '⚡', xp: 180, rank: 4 },
    { id: '4', name: 'Noor H.', avatarEmoji: '⭐', xp: 155, rank: 5 },
    { id: '5', name: 'Tariq K.', avatarEmoji: '🦅', xp: 110, rank: 6 },
    { id: '6', name: 'Fatima E.', avatarEmoji: '🌺', xp: 90, rank: 7 },
    { id: '7', name: 'Omar S.', avatarEmoji: '🚀', xp: 70, rank: 8, isDemotionZone: true },
    { id: '8', name: 'Salma D.', avatarEmoji: '🎨', xp: 45, rank: 9, isDemotionZone: true },
    { id: '9', name: 'Bilal R.', avatarEmoji: '🎯', xp: 20, rank: 10, isDemotionZone: true },
  ];

  return list
    .sort((a, b) => b.xp - a.xp)
    .map((entry, index) => {
      const rank = index + 1;
      return {
        ...entry,
        rank,
        isPromotionZone: rank <= 3,
        isDemotionZone: rank >= 8,
      };
    });
}
