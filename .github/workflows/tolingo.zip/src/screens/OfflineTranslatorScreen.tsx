import React, { useState, useEffect } from 'react';
import {
  ArrowRightLeft,
  Volume2,
  Volume1,
  Copy,
  Check,
  X,
  Mic,
  MicOff,
  Settings,
  Pin,
  Download,
  Trash2,
  Wifi,
  WifiOff,
  Maximize2,
  BookOpen,
  Sparkles,
  HardDrive,
  CheckCircle2,
} from 'lucide-react';
import {
  ALL_TRANSLATION_LANGUAGES,
  SupportedTranslationLanguage,
  offlineTranslationService,
  OFFLINE_DICTIONARY,
} from '../services/offlineTranslator';
import { OfflineLanguagePack } from '../types';
import { audioService } from '../services/audio';
import {
  isSpeechRecognitionSupported,
  startSpeechListening,
} from '../services/speech';

interface OfflineTranslatorScreenProps {
  onBackToLearn: () => void;
}

export const OfflineTranslatorScreen: React.FC<OfflineTranslatorScreenProps> = ({
  onBackToLearn,
}) => {
  // Pinned / Selected Language Pair
  const [sourceLang, setSourceLang] = useState('ar');
  const [targetLang, setTargetLang] = useState('en');
  const [isPairPinned, setIsPairPinned] = useState(true);

  // Text inputs
  const [inputText, setInputText] = useState('أهلاً وسهلاً بك، كيف حالك؟');
  const [outputText, setOutputText] = useState('');
  const [pronunciation, setPronunciation] = useState<string | undefined>('');
  const [copied, setCopied] = useState(false);

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);

  // Modals & Settings
  const [showLanguageSettingsModal, setShowLanguageSettingsModal] = useState(false);
  const [selectingType, setSelectingType] = useState<'source' | 'target' | null>(null);
  const [showFullscreenTranslation, setShowFullscreenTranslation] = useState(false);

  // Offline Packs & Mode
  const [packs, setPacks] = useState<OfflineLanguagePack[]>([]);
  const [downloadingPackId, setDownloadingPackId] = useState<string | null>(null);
  const [simulatedOffline, setSimulatedOffline] = useState(true);
  const [searchLangQuery, setSearchLangQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  // Load pinned pair and packs on mount
  useEffect(() => {
    const pinned = offlineTranslationService.getPinnedPair();
    setSourceLang(pinned.sourceLang || 'ar');
    setTargetLang(pinned.targetLang || 'en');
    setPacks(offlineTranslationService.getPacks());
  }, []);

  // Run translation whenever input or language changes
  useEffect(() => {
    if (!inputText.trim()) {
      setOutputText('');
      setPronunciation(undefined);
      return;
    }
    const res = offlineTranslationService.translateOffline(inputText, sourceLang, targetLang);
    setOutputText(res.translatedText);
    setPronunciation(res.pronunciation);
  }, [inputText, sourceLang, targetLang]);

  // Swap Languages
  const handleSwapLanguages = () => {
    const prevSource = sourceLang;
    const prevTarget = targetLang;
    setSourceLang(prevTarget);
    setTargetLang(prevSource);
    setInputText(outputText);
    setOutputText(inputText);
  };

  // Pin Current Pair
  const handlePinPair = () => {
    offlineTranslationService.savePinnedPair({ sourceLang, targetLang });
    setIsPairPinned(true);
  };

  // Copy Result
  const handleCopy = () => {
    if (!outputText) return;
    navigator.clipboard.writeText(outputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Voice Input
  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      setInputText(sourceLang === 'ar' ? 'أين محطة القطار؟' : 'Where is the train station?');
      return;
    }

    setIsRecording(true);
    startSpeechListening(
      sourceLang === 'ar' ? 'ar-SA' : 'en-US',
      (transcript) => {
        setInputText(transcript);
        setIsRecording(false);
      },
      () => setIsRecording(false),
      () => setIsRecording(false)
    );
  };

  // Download Language Pack
  const handleDownloadPack = (packId: string) => {
    setDownloadingPackId(packId);
    let progress = 0;
    const interval = setInterval(() => {
      progress += 25;
      setPacks((prev) =>
        prev.map((p) => (p.id === packId ? { ...p, downloadProgress: progress } : p))
      );

      if (progress >= 100) {
        clearInterval(interval);
        setDownloadingPackId(null);
        setPacks((prev) => {
          const updated = prev.map((p) =>
            p.id === packId
              ? {
                  ...p,
                  isDownloaded: true,
                  downloadProgress: 100,
                  downloadDate: new Date().toISOString().split('T')[0],
                }
              : p
          );
          offlineTranslationService.savePacks(updated);
          return updated;
        });
      }
    }, 250);
  };

  // Delete Pack
  const handleDeletePack = (packId: string) => {
    setPacks((prev) => {
      const updated = prev.map((p) =>
        p.id === packId ? { ...p, isDownloaded: false, downloadProgress: 0, downloadDate: undefined } : p
      );
      offlineTranslationService.savePacks(updated);
      return updated;
    });
  };

  const sourceLangObj = ALL_TRANSLATION_LANGUAGES.find((l) => l.code === sourceLang) || ALL_TRANSLATION_LANGUAGES[0];
  const targetLangObj = ALL_TRANSLATION_LANGUAGES.find((l) => l.code === targetLang) || ALL_TRANSLATION_LANGUAGES[1];

  const phrasebook = OFFLINE_DICTIONARY.pack_ar_en || [];
  const categories = ['All', 'Greetings', 'Travel', 'Dining', 'Emergency', 'Work', 'Time'];

  const filteredPhrases =
    activeCategory === 'All'
      ? phrasebook
      : phrasebook.filter((p) => p.category === activeCategory);

  const filteredLanguages = ALL_TRANSLATION_LANGUAGES.filter(
    (l) =>
      l.nativeName.toLowerCase().includes(searchLangQuery.toLowerCase()) ||
      l.name.toLowerCase().includes(searchLangQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#131F24] pb-28 text-white select-none">
      <div className="max-w-md mx-auto px-4 py-4 space-y-4">
        {/* Top Header: Title & Network Mode Toggle */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-white font-['Tajawal','Nunito',sans-serif]">
              منطقة الترجمة الذكية 🌐
            </h2>
            <p className="text-xs text-stone-400">تعمل بدون إنترنت باستخدام حزم اللغات المثبتة</p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSimulatedOffline(!simulatedOffline)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer ${
                simulatedOffline
                  ? 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-[#1CB0F6]'
                  : 'bg-[#58CC02]/20 border-[#58CC02] text-[#58CC02]'
              }`}
            >
              {simulatedOffline ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
              <span>{simulatedOffline ? 'بدون إنترنت' : 'متصل'}</span>
            </button>

            <button
              onClick={() => setShowLanguageSettingsModal(true)}
              className="p-2 rounded-xl bg-[#1C2B32] border border-[#2A3A42] text-stone-300 hover:text-white hover:border-[#F26B3A] transition-colors cursor-pointer"
              title="إعدادات اللغات"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 1. LANGUAGE SELECTOR BAR: اللغة من إلى (مع زر التبديل والتثبيت) */}
        <div className="p-3 rounded-2xl bg-[#1C2B32] border-2 border-[#2A3A42] flex items-center justify-between gap-2 shadow-lg">
          {/* Source Language Button */}
          <button
            onClick={() => {
              setSelectingType('source');
              setShowLanguageSettingsModal(true);
            }}
            className="flex-1 py-2 px-3 rounded-xl bg-[#131F24] border border-[#2A3A42] hover:border-[#1CB0F6] flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <span className="text-xl">{sourceLangObj.flag}</span>
            <span className="text-xs font-bold text-white">{sourceLangObj.nativeName}</span>
          </button>

          {/* Swap Languages Button (⇄) */}
          <button
            onClick={handleSwapLanguages}
            className="p-2 rounded-xl bg-[#2A3A42] hover:bg-[#32454f] active:rotate-180 transition-all text-[#FF9600] cursor-pointer shrink-0 shadow"
            title="تبديل اتجاه الترجمة"
          >
            <ArrowRightLeft className="w-4 h-4" />
          </button>

          {/* Target Language Button */}
          <button
            onClick={() => {
              setSelectingType('target');
              setShowLanguageSettingsModal(true);
            }}
            className="flex-1 py-2 px-3 rounded-xl bg-[#131F24] border border-[#2A3A42] hover:border-[#1CB0F6] flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <span className="text-xl">{targetLangObj.flag}</span>
            <span className="text-xs font-bold text-white">{targetLangObj.nativeName}</span>
          </button>

          {/* Pin default pair button */}
          <button
            onClick={handlePinPair}
            className={`p-2 rounded-xl border transition-colors cursor-pointer ${
              isPairPinned
                ? 'bg-[#58CC02]/20 border-[#58CC02] text-[#58CC02]'
                : 'bg-[#131F24] border-[#2A3A42] text-stone-400 hover:text-white'
            }`}
            title="تثبيت هذا الزوج اللغوي كافتراضي"
          >
            <Pin className="w-4 h-4" />
          </button>
        </div>

        {/* 2. INPUT BOX: خانة الكتابة */}
        <div className="relative p-4 rounded-3xl bg-[#1C2B32] border-2 border-[#2A3A42] shadow-xl space-y-3">
          <div className="flex items-center justify-between text-xs text-stone-400">
            <span className="font-bold flex items-center gap-1.5">
              <span>أدخل النص ({sourceLangObj.nativeName}):</span>
            </span>
            {inputText && (
              <button
                onClick={() => setInputText('')}
                className="text-stone-400 hover:text-white p-1 rounded-lg hover:bg-[#131F24] cursor-pointer"
                title="مسح النص"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <textarea
            rows={3}
            value={inputText}
            onChange={(e) => {
              setInputText(e.target.value);
              setIsPairPinned(false);
            }}
            placeholder="اكتب هنا ما ترغب في ترجمته..."
            dir={sourceLangObj.isRtl ? 'rtl' : 'ltr'}
            className="w-full bg-transparent text-white font-bold text-base outline-none resize-none placeholder-stone-500 leading-relaxed"
          />

          {/* Bottom input toolbar */}
          <div className="flex items-center justify-between pt-2 border-t border-[#2A3A42] text-xs">
            <div className="flex items-center gap-2">
              {/* Mic Speech Button */}
              <button
                onClick={toggleRecording}
                className={`p-2 rounded-xl border flex items-center gap-1.5 transition-colors cursor-pointer ${
                  isRecording
                    ? 'bg-[#FF4B4B] border-[#b92b2b] text-white animate-pulse'
                    : 'bg-[#131F24] border-[#2A3A42] text-stone-300 hover:text-[#58CC02]'
                }`}
                title="تحدث للإدخال الصوتي"
              >
                <Mic className="w-4 h-4" />
                <span className="text-[11px] font-bold">
                  {isRecording ? 'جارٍ الاستماع...' : 'تحدث'}
                </span>
              </button>

              {/* TTS Listen to input */}
              {inputText && (
                <button
                  onClick={() => audioService.speak(inputText, false, sourceLang === 'ar' ? 'ar-SA' : 'en-US')}
                  className="p-2 rounded-xl bg-[#131F24] border border-[#2A3A42] text-stone-300 hover:text-[#1CB0F6] cursor-pointer"
                  title="استماع للنص المدخل"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              )}
            </div>

            <span className="text-[11px] text-stone-500 font-mono">
              {inputText.length} حرف
            </span>
          </div>
        </div>

        {/* 3. OUTPUT BOX: إظهار الترجمة */}
        <div className="relative p-4 rounded-3xl bg-gradient-to-b from-[#1C2B32] to-[#152329] border-2 border-[#1CB0F6]/50 shadow-2xl space-y-3">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-[#1CB0F6] font-black">
              <Sparkles className="w-4 h-4" />
              <span>الترجمة الفورية ({targetLangObj.nativeName}):</span>
            </div>

            <div className="flex items-center gap-1.5">
              {/* Fullscreen Button */}
              <button
                onClick={() => setShowFullscreenTranslation(true)}
                className="p-1.5 rounded-lg bg-[#131F24] border border-[#2A3A42] text-stone-300 hover:text-white cursor-pointer"
                title="تكبير العرض"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>

              {/* Copy Button */}
              <button
                onClick={handleCopy}
                className="p-1.5 rounded-lg bg-[#131F24] border border-[#2A3A42] text-stone-300 hover:text-white cursor-pointer"
                title="نسخ الترجمة"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-[#58CC02]" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Translated Text */}
          <div
            dir={targetLangObj.isRtl ? 'rtl' : 'ltr'}
            className="text-xl font-black text-white font-['Nunito','Tajawal',sans-serif] leading-relaxed min-h-[48px]"
          >
            {outputText || <span className="text-stone-500 text-sm font-normal">ستظهر الترجمة هنا...</span>}
          </div>

          {/* Pronunciation guide & Audio Listeners */}
          {outputText && (
            <div className="pt-2 border-t border-[#2A3A42] flex items-center justify-between">
              <div className="text-xs text-[#FFC857] font-mono">
                {pronunciation ? `[النطق: ${pronunciation}]` : ''}
              </div>

              <div className="flex items-center gap-1">
                {/* Normal Audio */}
                <button
                  onClick={() => audioService.speak(outputText, false, targetLang === 'ar' ? 'ar-SA' : 'en-US')}
                  className="p-2 rounded-xl bg-[#1CB0F6] hover:bg-[#189cdb] text-white shadow cursor-pointer active:scale-95"
                  title="نطق عادي"
                >
                  <Volume2 className="w-4 h-4" />
                </button>

                {/* Slow Audio */}
                <button
                  onClick={() => audioService.speak(outputText, true, targetLang === 'ar' ? 'ar-SA' : 'en-US')}
                  className="p-2 rounded-xl bg-[#131F24] border border-[#2A3A42] text-[#FFC857] hover:bg-[#2A3A42] cursor-pointer"
                  title="نطق بطيء"
                >
                  <Volume1 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 4. QUICK PHRASEBOOK (دليل العبارات السريعة مع الفئات) */}
        <div className="p-4 rounded-3xl bg-[#1C2B32] border border-[#2A3A42] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#FF9600]" />
              <h3 className="text-xs font-black text-white font-['Tajawal',sans-serif]">
                عبارات جاهزة بدون إنترنت
              </h3>
            </div>
            <span className="text-[10px] text-stone-400">اضغط للترجمة الفورية</span>
          </div>

          {/* Categories */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-xl text-[11px] font-bold shrink-0 transition-colors cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-[#FF9600] text-white font-black'
                    : 'bg-[#131F24] text-stone-400 border border-[#2A3A42]'
                }`}
              >
                {cat === 'All'
                  ? 'الكل'
                  : cat === 'Greetings'
                  ? 'تحيات'
                  : cat === 'Travel'
                  ? 'سفر'
                  : cat === 'Dining'
                  ? 'طعام'
                  : cat === 'Emergency'
                  ? 'طوارئ'
                  : cat === 'Work'
                  ? 'عمل'
                  : cat === 'Time'
                  ? 'وقت'
                  : cat}
              </button>
            ))}
          </div>

          {/* Phrases items */}
          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {filteredPhrases.slice(0, 10).map((item, idx) => (
              <div
                key={idx}
                onClick={() => {
                  setInputText(item.sourceText);
                  setOutputText(item.translatedText);
                  setPronunciation(item.pronunciation);
                }}
                className="p-2.5 rounded-xl bg-[#131F24]/70 border border-[#2A3A42] hover:border-[#1CB0F6]/60 flex items-center justify-between cursor-pointer active:scale-98 transition-all"
              >
                <div>
                  <div className="text-xs font-bold text-white">{item.sourceText}</div>
                  <div className="text-[11px] text-[#1CB0F6] font-semibold mt-0.5">
                    {item.translatedText}
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    audioService.speak(item.translatedText, false);
                  }}
                  className="p-1 rounded-lg text-stone-400 hover:text-white"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 5. LANGUAGE SETTINGS & ALL LANGUAGES MODAL (إظهار جميع اللغات وتثبيتها) */}
      {showLanguageSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-md bg-[#1C2B32] border-2 border-[#2A3A42] rounded-3xl p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            {/* Close */}
            <button
              onClick={() => {
                setShowLanguageSettingsModal(false);
                setSelectingType(null);
              }}
              className="absolute top-4 end-4 text-stone-400 hover:text-white p-1 rounded-full bg-[#131F24] border border-[#2A3A42] cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black text-white mb-1 font-['Tajawal',sans-serif]">
              {selectingType === 'source'
                ? 'اختر لغة الإدخال (من)'
                : selectingType === 'target'
                ? 'اختر لغة الترجمة (إلى)'
                : 'إعدادات اللغات وحزم الأوفلاين'}
            </h3>
            <p className="text-xs text-stone-400 mb-4">
              يمكنك تحديد وتثبيت أي لغتين للترجمة الفورية وحفظ الحزم بدون إنترنت
            </p>

            {/* Pin current pair action */}
            <div className="p-3 rounded-2xl bg-[#131F24] border border-[#2A3A42] flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Pin className="w-4 h-4 text-[#58CC02]" />
                <span className="text-xs font-bold text-white">
                  تثبيت ({sourceLangObj.nativeName} ⇄ {targetLangObj.nativeName}) كافتراضية
                </span>
              </div>
              <button
                onClick={handlePinPair}
                className="px-3 py-1 rounded-xl bg-[#58CC02] text-white text-xs font-black shadow cursor-pointer active:scale-95"
              >
                تثبيت
              </button>
            </div>

            {/* Search Language */}
            <input
              type="text"
              value={searchLangQuery}
              onChange={(e) => setSearchLangQuery(e.target.value)}
              placeholder="ابحث عن لغة..."
              className="w-full px-3.5 py-2 rounded-xl bg-[#131F24] border border-[#2A3A42] focus:border-[#1CB0F6] text-xs text-white mb-3 outline-none"
            />

            {/* All Languages List */}
            <div className="space-y-1.5 mb-6">
              {filteredLanguages.map((lang) => {
                const isSelected =
                  selectingType === 'source'
                    ? sourceLang === lang.code
                    : selectingType === 'target'
                    ? targetLang === lang.code
                    : sourceLang === lang.code || targetLang === lang.code;

                return (
                  <div
                    key={lang.code}
                    onClick={() => {
                      if (selectingType === 'source') {
                        setSourceLang(lang.code);
                        setShowLanguageSettingsModal(false);
                        setSelectingType(null);
                      } else if (selectingType === 'target') {
                        setTargetLang(lang.code);
                        setShowLanguageSettingsModal(false);
                        setSelectingType(null);
                      }
                    }}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-white'
                        : 'bg-[#131F24] border-[#2A3A42] text-stone-300 hover:border-stone-400'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-2xl">{lang.flag}</span>
                      <div>
                        <div className="text-sm font-bold text-white">{lang.nativeName}</div>
                        <div className="text-[10px] text-stone-400">{lang.name}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {lang.hasOfflinePack && (
                        <span className="px-2 py-0.5 rounded-full bg-[#58CC02]/20 text-[#58CC02] text-[10px] font-bold">
                          حزمة أوفلاين
                        </span>
                      )}
                      {isSelected && <Check className="w-4 h-4 text-[#1CB0F6]" />}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Downloadable Packs Manager */}
            <div className="border-t border-[#2A3A42] pt-4 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-stone-300">
                <span className="flex items-center gap-1.5">
                  <HardDrive className="w-4 h-4 text-[#1CB0F6]" />
                  <span>حزم اللغات المحفوظة في الجهاز:</span>
                </span>
              </div>

              <div className="space-y-2">
                {packs.map((pack) => {
                  const isDownloading = downloadingPackId === pack.id;
                  return (
                    <div
                      key={pack.id}
                      className="p-3 rounded-xl bg-[#131F24] border border-[#2A3A42] flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-bold text-white">{pack.name}</div>
                        <div className="text-[10px] text-stone-400 mt-0.5">
                          {pack.sizeMb} MB • {pack.vocabularyCount} مصطلح
                        </div>
                      </div>

                      <div>
                        {pack.isDownloaded ? (
                          <div className="flex items-center gap-2">
                            <span className="text-[#58CC02] font-black text-[10px] flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              محمّلة
                            </span>
                            {pack.id !== 'pack_ar_en' && (
                              <button
                                onClick={() => handleDeletePack(pack.id)}
                                className="text-stone-500 hover:text-[#FF4B4B]"
                                title="حذف الحزمة"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        ) : (
                          <button
                            onClick={() => handleDownloadPack(pack.id)}
                            disabled={isDownloading}
                            className="px-3 py-1 rounded-xl bg-[#1CB0F6] text-white font-bold flex items-center gap-1"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>{isDownloading ? `${pack.downloadProgress}%` : 'تحميل'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. FULLSCREEN TRANSLATION MODAL */}
      {showFullscreenTranslation && (
        <div className="fixed inset-0 z-50 bg-[#131F24] p-6 flex flex-col justify-between animate-fade-in select-none">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-stone-400">
              {sourceLangObj.nativeName} ➔ {targetLangObj.nativeName}
            </span>
            <button
              onClick={() => setShowFullscreenTranslation(false)}
              className="p-2 rounded-xl bg-[#1C2B32] border border-[#2A3A42] text-white cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="my-auto text-center space-y-4">
            <p className="text-stone-400 text-lg">{inputText}</p>
            <h1 className="text-4xl font-black text-white leading-tight font-['Tajawal','Nunito',sans-serif]">
              {outputText}
            </h1>
            {pronunciation && (
              <p className="text-[#FFC857] font-mono text-base">[{pronunciation}]</p>
            )}
          </div>

          <div className="flex items-center justify-center gap-4">
            <button
              onClick={() => audioService.speak(outputText, false, targetLang === 'ar' ? 'ar-SA' : 'en-US')}
              className="px-6 py-3 rounded-2xl bg-[#1CB0F6] text-white font-black flex items-center gap-2 shadow-lg"
            >
              <Volume2 className="w-5 h-5" />
              <span>استماع</span>
            </button>
            <button
              onClick={handleCopy}
              className="px-6 py-3 rounded-2xl bg-[#1C2B32] border border-[#2A3A42] text-white font-bold flex items-center gap-2"
            >
              <Copy className="w-5 h-5" />
              <span>نسخ</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
