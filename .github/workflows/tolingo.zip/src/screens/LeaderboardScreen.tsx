import React from 'react';
import { Trophy, Clock, ArrowUp, ArrowDown } from 'lucide-react';
import { LeaderboardEntry, LeagueTier, LEAGUE_TIERS } from '../types';
import { LocalizedStrings } from '../localization/strings';

interface LeaderboardScreenProps {
  currentLeague: LeagueTier;
  leaderboardEntries: LeaderboardEntry[];
  strings: LocalizedStrings;
}

export const LeaderboardScreen: React.FC<LeaderboardScreenProps> = ({
  currentLeague,
  leaderboardEntries,
  strings,
}) => {
  const leagueInfo = LEAGUE_TIERS[currentLeague] || LEAGUE_TIERS.SILVER;

  return (
    <div className="min-h-screen bg-[#131F24] pb-28 text-white select-none">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* League Header Card */}
        <div className="p-6 rounded-3xl bg-[#1C2B32] border-2 border-[#2A3A42] text-center shadow-xl">
          <div className="w-20 h-20 mx-auto mb-3 rounded-3xl bg-gradient-to-tr from-stone-700 to-stone-500 border-2 border-stone-400/40 flex items-center justify-center text-4xl shadow-inner">
            {leagueInfo.badge}
          </div>
          <h2 className="text-2xl font-black text-white font-['Tajawal','Nunito',sans-serif]">
            دوري {leagueInfo.displayName}
          </h2>
          <p className="text-xs text-stone-300 mt-1">
            تنافس أسبوعياً مع أفضل المتعلمين للترقية إلى الدوري الذهبي 🥇
          </p>

          <div className="mt-4 pt-3 border-t border-[#2A3A42] flex items-center justify-center gap-1.5 text-xs text-[#FFC857] font-bold">
            <Clock className="w-4 h-4" />
            <span>3 {strings.daysLeft}</span>
          </div>
        </div>

        {/* Promotion Zone Legend */}
        <div className="p-3 rounded-2xl bg-[#131F24] border border-[#2A3A42] flex items-center justify-between text-xs font-bold text-stone-400">
          <div className="flex items-center gap-1.5 text-[#58CC02]">
            <ArrowUp className="w-4 h-4" />
            <span>أفضل 3: ترقية ⬆️</span>
          </div>
          <div className="flex items-center gap-1.5 text-[#FF4B4B]">
            <ArrowDown className="w-4 h-4" />
            <span>آخر 3: هبوط ⬇️</span>
          </div>
        </div>

        {/* Leaderboard List */}
        <div className="space-y-2.5">
          {leaderboardEntries.map((entry) => {
            const isTop3 = entry.rank <= 3;
            const isBottom3 = entry.rank >= 8;

            return (
              <div
                key={entry.id}
                className={`p-3.5 rounded-2xl border-2 flex items-center justify-between gap-3 transition-all ${
                  entry.isCurrentUser
                    ? 'bg-[#1CB0F6]/15 border-[#1CB0F6] ring-2 ring-[#1CB0F6]/30 shadow-lg'
                    : isTop3
                    ? 'bg-[#1C2B32] border-[#58CC02]/40'
                    : isBottom3
                    ? 'bg-[#1C2B32] border-[#FF4B4B]/30'
                    : 'bg-[#1C2B32] border-[#2A3A42]'
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Rank Number */}
                  <span
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-black text-xs font-['Nunito',sans-serif] ${
                      entry.rank === 1
                        ? 'bg-[#FFD700] text-amber-950 shadow'
                        : entry.rank === 2
                        ? 'bg-[#C0C0C0] text-stone-900 shadow'
                        : entry.rank === 3
                        ? 'bg-[#CD7F32] text-amber-100 shadow'
                        : 'bg-[#131F24] text-stone-400 border border-[#2A3A42]'
                    }`}
                  >
                    {entry.rank}
                  </span>

                  {/* Avatar */}
                  <span className="text-2xl">{entry.avatarEmoji}</span>

                  {/* Name */}
                  <div>
                    <h4
                      className={`text-sm font-black ${
                        entry.isCurrentUser ? 'text-[#1CB0F6]' : 'text-white'
                      }`}
                    >
                      {entry.name}
                    </h4>
                    {entry.isCurrentUser && (
                      <span className="text-[10px] text-stone-400 font-bold">أنت</span>
                    )}
                  </div>
                </div>

                {/* XP */}
                <div className="flex items-center gap-1.5 font-['Nunito',sans-serif]">
                  <span className="text-base font-black text-white">{entry.xp}</span>
                  <span className="text-xs font-bold text-[#FFC857]">XP</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
