import React, { useState } from 'react';
import { Dumbbell, Volume2, CheckCircle2, Heart, Sparkles, Smile } from 'lucide-react';
import { MistakeItem } from '../types';
import { LocalizedStrings } from '../localization/strings';
import { audioService } from '../services/audio';

interface MistakesReviewScreenProps {
  mistakes: MistakeItem[];
  strings: LocalizedStrings;
  onResolveMistake: (mistakeId: string) => void;
}

export const MistakesReviewScreen: React.FC<MistakesReviewScreenProps> = ({
  mistakes,
  strings,
  onResolveMistake,
}) => {
  const [activePracticeId, setActivePracticeId] = useState<string | null>(null);
  const [userTypedAnswer, setUserTypedAnswer] = useState('');
  const [checkResult, setCheckResult] = useState<'idle' | 'correct' | 'wrong'>('idle');

  const handleStartPractice = (item: MistakeItem) => {
    setActivePracticeId(item.id);
    setUserTypedAnswer('');
    setCheckResult('idle');
  };

  const handleVerifyAnswer = (item: MistakeItem) => {
    const isCorrect =
      userTypedAnswer.trim().toLowerCase() === item.correctAnswer.trim().toLowerCase();

    if (isCorrect) {
      audioService.playCorrectSound();
      setCheckResult('correct');
      setTimeout(() => {
        onResolveMistake(item.id);
        setActivePracticeId(null);
      }, 900);
    } else {
      audioService.playWrongSound();
      setCheckResult('wrong');
    }
  };

  return (
    <div className="min-h-screen bg-[#131F24] pb-28 text-white select-none">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-white font-['Tajawal','Nunito',sans-serif]">
              {strings.reviewMistakes}
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              {strings.practiceMistakesToEarnHearts}
            </p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-[#FF4B4B]/20 border border-[#FF4B4B]/40 flex items-center justify-center text-[#FF4B4B]">
            <Dumbbell className="w-5 h-5" />
          </div>
        </div>

        {/* Empty State */}
        {mistakes.length === 0 ? (
          <div className="p-8 rounded-3xl bg-[#1C2B32] border border-[#2A3A42] text-center space-y-4 my-8">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-[#58CC02]/20 border border-[#58CC02]/40 flex items-center justify-center text-4xl">
              🌟
            </div>
            <h3 className="text-lg font-black text-white">
              {strings.noMistakesYet}
            </h3>
            <p className="text-xs text-stone-300 leading-relaxed max-w-xs mx-auto">
              ذاكرتك ممتازة! تابع مسارك التعليمي، وعند ارتكاب أي خطأ سيظهر هنا لتتدرب عليه وتستعيد قلوبك مجاناً.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs font-bold text-stone-400">
              <span>قائمة الأخطاء المحفوظة ({mistakes.length}):</span>
              <span className="text-[#58CC02] flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 fill-current text-[#FF4B4B]" />
                +1 قلب لكل تصحيح
              </span>
            </div>

            {mistakes.map((item) => {
              const isPracticing = activePracticeId === item.id;

              return (
                <div
                  key={item.id}
                  className="p-4 rounded-2xl bg-[#1C2B32] border-2 border-[#2A3A42] shadow-sm space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-xs text-stone-400 font-bold mb-0.5">
                        {item.promptTranslation || 'أعد صياغة الكلمة أو العبارة:'}
                      </div>
                      <h4 className="text-lg font-black text-white font-['Tajawal','Nunito',sans-serif]">
                        {item.question}
                      </h4>
                    </div>
                    <button
                      onClick={() => audioService.speak(item.correctAnswer, false)}
                      className="p-2 rounded-xl bg-[#131F24] border border-[#2A3A42] text-[#1CB0F6] hover:bg-[#2A3A42] cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>

                  {isPracticing ? (
                    <div className="space-y-2.5 pt-2 border-t border-[#2A3A42]">
                      <input
                        type="text"
                        value={userTypedAnswer}
                        onChange={(e) => setUserTypedAnswer(e.target.value)}
                        placeholder="اكتب الإجابة الصحيحة بالإنجليزية..."
                        className="w-full px-3 py-2.5 rounded-xl bg-[#131F24] border border-[#2A3A42] focus:border-[#58CC02] text-sm text-white font-bold outline-none"
                      />

                      {checkResult === 'wrong' && (
                        <div className="text-xs text-[#FF4B4B] font-bold">
                          غير دقيق! الحل الصحيح: {item.correctAnswer}
                        </div>
                      )}

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleVerifyAnswer(item)}
                          className="flex-1 py-2.5 px-3 rounded-xl font-black text-xs bg-[#58CC02] hover:bg-[#46A302] border-b-2 border-[#378002] text-white cursor-pointer shadow active:scale-95"
                        >
                          تحقق واكسب قلباً ❤️
                        </button>
                        <button
                          onClick={() => setActivePracticeId(null)}
                          className="py-2.5 px-3 rounded-xl font-bold text-xs bg-[#131F24] text-stone-400 hover:text-white cursor-pointer"
                        >
                          إلغاء
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="pt-2 border-t border-[#2A3A42] flex items-center justify-between">
                      <div className="text-[11px] text-stone-400">
                        إجابتك السابقة:{' '}
                        <span className="text-[#FF4B4B] font-semibold">
                          "{item.userAnswer || '—'}"
                        </span>
                      </div>
                      <button
                        onClick={() => handleStartPractice(item)}
                        className="px-3 py-1.5 rounded-xl font-black text-xs bg-[#2A3A42] hover:bg-[#32454f] text-[#58CC02] border border-[#32454f] cursor-pointer shadow-sm active:scale-95 flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>تصحيح الآن</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
