import React, { useState } from 'react';
import { Zap, Gift, Trophy, Sparkles } from 'lucide-react';
import { Course, LessonModel, UnitModel } from '../types';
import { LocalizedStrings } from '../localization/strings';
import {
  DuolingoNode,
  WoodenTreasureChest,
  SleepingMascotWatermark,
} from '../components/DuolingoNode';

interface HomeScreenProps {
  course: Course;
  strings: LocalizedStrings;
  onStartLesson: (unitId: string, lesson: LessonModel, isSkippingUnit?: boolean) => void;
  onClaimChest: (unitId: string) => void;
  onOpenTranslator: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  course,
  strings,
  onStartLesson,
  onClaimChest,
  onOpenTranslator,
}) => {
  const [jumpTarget, setJumpTarget] = useState<{ unitId: string; lesson: LessonModel } | null>(null);
  const [skipUnitTarget, setSkipUnitTarget] = useState<{ unit: UnitModel; examLesson: LessonModel } | null>(null);
  const [claimedChestUnit, setClaimedChestUnit] = useState<UnitModel | null>(null);

  // Find overall current active lesson across all units to highlight
  let foundActive = false;

  return (
    <div className="min-h-screen bg-[#131F24] pb-28 text-white select-none">
      <div className="max-w-md mx-auto px-4 py-3 space-y-10">
        {/* Monthly Challenge Quest Badge on top right */}
        <div className="flex justify-end pt-1">
          <div className="px-3 py-1.5 rounded-2xl bg-[#5B21B6] border-b-4 border-[#4C1D95] shadow-lg flex items-center gap-2 cursor-pointer hover:scale-105 transition-transform">
            <span className="text-xl">🧙‍♀️</span>
            <div className="text-start leading-tight">
              <div className="text-[10px] text-purple-200 font-bold">تحدي الشهر</div>
              <div className="text-xs font-black text-white">23 يوماً متبقية</div>
            </div>
          </div>
        </div>

        {/* Iterate through ALL Course Units (كل الدروس والوحدات السابقة بالتصميم الجديد) */}
        {course.units.map((unit) => {
          const isAllCompleted = unit.lessons.every((l) => l.isCompleted);
          const completedCount = unit.lessons.filter((l) => l.isCompleted).length;
          const remainingCount = unit.lessons.length - completedCount;
          const examLesson = unit.lessons.find((l) => l.isExam) || unit.lessons[unit.lessons.length - 1];

          // Can skip by exam when 3 stages or less remain before unit completion
          const canSkipByExam = remainingCount <= 3 && remainingCount > 1 && !isAllCompleted && !!examLesson;

          return (
            <section key={unit.id} className="relative">
              {/* DUOLINGO AUTHENTIC UNIT HEADER CARD (القسم X، الوحدة Y) */}
              <div className="relative mb-6">
                <div className="relative overflow-hidden rounded-2xl bg-[#58CC02] border-b-[6px] border-[#46A302] text-white shadow-xl flex items-stretch">
                  {/* Left Notebook / Guidebook tab with vertical divider */}
                  <div
                    onClick={() => onOpenTranslator()}
                    className="px-4 py-4 bg-[#4eb602]/50 border-e-2 border-[#46A302] flex items-center justify-center shrink-0 cursor-pointer hover:bg-[#4eb602]/70 transition-colors"
                    title="كتيب الملاحظات والترجمة"
                  >
                    <svg viewBox="0 0 24 24" className="w-7 h-7 text-white fill-white">
                      <path d="M4 3h16a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zm2 3v12h12V6H6zm2 2h8v2H8V8zm0 4h8v2H8v-2z" />
                    </svg>
                  </div>

                  {/* Right Title section */}
                  <div className="flex-1 px-4 py-3 flex flex-col justify-center text-start">
                    <span className="text-xs font-black text-green-100/90 font-['Tajawal','Nunito',sans-serif]">
                      {unit.sectionTitle} • {strings.unit} {unit.unitNumber}
                    </span>
                    <h2 className="text-xl font-black text-white font-['Tajawal','Nunito',sans-serif] mt-0.5">
                      {unit.title.replace(/^Unit \d+:\s*/, '')}
                    </h2>
                    <p className="text-xs text-green-100/80 line-clamp-1 mt-0.5">
                      {unit.description}
                    </p>
                  </div>
                </div>
              </div>

              {/* Grammar Milestone Tip */}
              {unit.grammarTip && (
                <div className="mx-auto max-w-xs mb-5 px-3 py-1.5 rounded-xl bg-[#1C2B32] border border-[#2A3A42] flex items-center gap-2 text-center text-xs font-bold text-amber-200/90 shadow-sm">
                  <span className="text-base">💡</span>
                  <span className="flex-1 leading-snug">{unit.grammarTip}</span>
                </div>
              )}

              {/* Skip remaining lessons prompt (قبل 3 مراحل من نهاية الوحدة) */}
              {canSkipByExam && (
                <div
                  onClick={() => setSkipUnitTarget({ unit, examLesson })}
                  className="mx-auto max-w-sm mb-6 p-2.5 rounded-2xl bg-gradient-to-r from-[#A855F7]/30 to-[#F26B3A]/20 border-2 border-[#A855F7]/60 hover:border-[#A855F7] flex items-center justify-between cursor-pointer active:scale-98 transition-all shadow-md animate-pulse"
                >
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-[#A855F7] fill-current" />
                    <span className="text-xs font-bold text-white">
                      تخطي ما تبقى من الوحدة بالامتحان ⏩ ({remainingCount} متبقية)
                    </span>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-[#A855F7] text-white text-[10px] font-black shrink-0">
                    امتحان
                  </span>
                </div>
              )}

              {/* Winding Path Nodes */}
              <div className="relative flex flex-col items-center py-4 space-y-7">
                {/* Sleeping Mascot Watermark on the left on even units */}
                {unit.unitNumber % 2 === 0 && (
                  <div className="absolute top-28 left-4 z-0">
                    <SleepingMascotWatermark />
                  </div>
                )}

                {unit.lessons.map((lesson, lIdx) => {
                  const isCompleted = lesson.isCompleted;
                  const isLocked = lesson.isLocked;

                  // Active is the first unlocked, non-completed lesson
                  let isActive = false;
                  if (!isCompleted && !isLocked && !foundActive) {
                    isActive = true;
                    foundActive = true;
                  }

                  // Sinusoidal winding horizontal offset
                  const offsetPx = Math.round(Math.sin(lIdx * 1.3) * 44);

                  return (
                    <React.Fragment key={lesson.id}>
                      <div
                        className="relative z-10"
                        style={{ transform: `translateX(${offsetPx}px)` }}
                      >
                        <DuolingoNode
                          lesson={lesson}
                          isActive={isActive}
                          onClick={() => onStartLesson(unit.id, lesson)}
                          onLockedClick={() => setJumpTarget({ unitId: unit.id, lesson })}
                        />
                      </div>

                      {/* Side Wooden Treasure Chest after lesson 2 */}
                      {lIdx === 1 && (
                        <div
                          className="relative z-10 my-1"
                          style={{ transform: `translateX(${offsetPx + 40}px)` }}
                        >
                          <WoodenTreasureChest
                            isClaimed={unit.bonusChestClaimed}
                            onClick={() => {
                              if (!unit.bonusChestClaimed && isAllCompleted) {
                                onClaimChest(unit.id);
                                setClaimedChestUnit(unit);
                              }
                            }}
                          />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      {/* Skip Unit Exam Confirmation Dialog */}
      {skipUnitTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-[#1C2B32] border-2 border-[#A855F7] rounded-3xl p-6 shadow-2xl text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#A855F7]/25 border border-[#A855F7] flex items-center justify-center text-[#A855F7]">
              <Trophy className="w-8 h-8 fill-current" />
            </div>
            <h3 className="text-xl font-black text-white mb-2 font-['Tajawal','Nunito',sans-serif]">
              امتحان تخطي باقي الوحدة 🏆
            </h3>
            <p className="text-sm text-stone-300 mb-6 leading-relaxed">
              إذا نجحت في هذا الامتحان الشامل، سيتم <strong>تخطي كافة الدروس المتبقية</strong> وفتح المستوى التالي فوراً!
            </p>
            <div className="space-y-2.5">
              <button
                onClick={() => {
                  const target = skipUnitTarget;
                  setSkipUnitTarget(null);
                  onStartLesson(target.unit.id, target.examLesson, true);
                }}
                className="w-full py-3.5 px-4 rounded-2xl font-black text-sm bg-[#A855F7] hover:bg-[#9333ea] border-b-4 border-[#7e22ce] text-white active:translate-y-1 active:border-b-0 cursor-pointer shadow-lg"
              >
                خوض الامتحان وتخطي الدروس 🚀
              </button>
              <button
                onClick={() => setSkipUnitTarget(null)}
                className="w-full py-2.5 px-4 rounded-2xl font-bold text-sm bg-[#2A3A42] hover:bg-[#344650] text-stone-300 cursor-pointer"
              >
                {strings.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Jump to here Dialog */}
      {jumpTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-[#1C2B32] border-2 border-[#2A3A42] rounded-3xl p-6 shadow-2xl text-center">
            <h3 className="text-xl font-black text-white mb-2 font-['Tajawal','Nunito',sans-serif]">
              {strings.jumpToLessonTitle}
            </h3>
            <p className="text-sm text-stone-300 mb-6 leading-relaxed">
              {strings.jumpToLessonPrompt}
              <br />
              <span className="font-bold text-[#FFC857] mt-1 block">
                {jumpTarget.lesson.title}
              </span>
            </p>
            <div className="space-y-2.5">
              <button
                onClick={() => {
                  const target = jumpTarget;
                  setJumpTarget(null);
                  onStartLesson(target.unitId, target.lesson);
                }}
                className="w-full py-3.5 px-4 rounded-2xl font-black text-sm bg-[#A855F7] hover:bg-[#9333ea] border-b-4 border-[#7e22ce] text-white active:translate-y-1 active:border-b-0 cursor-pointer shadow-lg"
              >
                {strings.jumpToLessonConfirm}
              </button>
              <button
                onClick={() => setJumpTarget(null)}
                className="w-full py-2.5 px-4 rounded-2xl font-bold text-sm bg-[#2A3A42] hover:bg-[#344650] text-stone-300 cursor-pointer"
              >
                {strings.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Chest Reward Dialog */}
      {claimedChestUnit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-[#1C2B32] border-2 border-[#2A3A42] rounded-3xl p-6 shadow-2xl text-center">
            <div className="w-20 h-20 mx-auto mb-4 rounded-3xl bg-gradient-to-tr from-[#FFC857] to-[#FFA000] border-2 border-white/40 flex items-center justify-center text-amber-950 shadow-2xl animate-bounce">
              <Gift className="w-12 h-12" />
            </div>
            <h3 className="text-2xl font-black text-white mb-2 font-['Tajawal','Nunito',sans-serif]">
              {strings.chestReward}
            </h3>
            <p className="text-sm text-stone-300 mb-4">
              تهانينا! لقد حصلت على مكافأة إتمام الوحدة:
            </p>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#1CB0F6]/20 border border-[#1CB0F6]/40 text-[#1CB0F6] font-black text-lg mb-6">
              <span>💎</span>
              <span>+{claimedChestUnit.bonusGems} {strings.gems}</span>
            </div>
            <button
              onClick={() => setClaimedChestUnit(null)}
              className="w-full py-3.5 px-4 rounded-2xl font-black text-sm bg-[#58CC02] hover:bg-[#46A302] border-b-4 border-[#378002] text-white active:translate-y-1 active:border-b-0 cursor-pointer shadow-lg"
            >
              {strings.continueText}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
