import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Heart,
  Volume2,
  Volume1,
  Mic,
  MicOff,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';
import { Exercise, LessonModel } from '../types';
import { LocalizedStrings } from '../localization/strings';
import { audioService } from '../services/audio';
import {
  isSpeechRecognitionSupported,
  startSpeechListening,
  calculateTextMatchScore,
} from '../services/speech';

interface LessonScreenProps {
  lesson: LessonModel;
  hearts: number;
  strings: LocalizedStrings;
  onCompleteLesson: (accuracyPercent: number) => void;
  onLoseHeart: () => void;
  onLogMistake: (exercise: Exercise, userAnswer: string) => void;
  onQuitLesson: () => void;
}

export const LessonScreen: React.FC<LessonScreenProps> = ({
  lesson,
  hearts,
  strings,
  onCompleteLesson,
  onLoseHeart,
  onLogMistake,
  onQuitLesson,
}) => {
  const exercises = useMemo(() => lesson.exercises || [], [lesson]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [totalMistakes, setTotalMistakes] = useState(0);
  const [showQuitModal, setShowQuitModal] = useState(false);

  // Current exercise state
  const currentEx: Exercise | undefined = exercises[currentIndex];

  // User input states
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null);
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [availableWords, setAvailableWords] = useState<string[]>([]);

  // Match pairs state
  const [pairSelectedEn, setPairSelectedEn] = useState<string | null>(null);
  const [pairSelectedAr, setPairSelectedAr] = useState<string | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<string[]>([]);
  const [mismatchedPair, setMismatchedPair] = useState<boolean>(false);

  // Speech recording state
  const [isRecording, setIsRecording] = useState(false);
  const [spokenTranscript, setSpokenTranscript] = useState('');
  const [speechScore, setSpeechScore] = useState<number | null>(null);

  // Feedback state: 'idle' | 'correct' | 'wrong'
  const [feedbackState, setFeedbackState] = useState<'idle' | 'correct' | 'wrong'>('idle');

  // Initialize or reset input states whenever current exercise changes
  useEffect(() => {
    if (!currentEx) return;

    setSelectedChoice(null);
    setFeedbackState('idle');
    setPairSelectedEn(null);
    setPairSelectedAr(null);
    setMatchedPairs([]);
    setMismatchedPair(false);
    setIsRecording(false);
    setSpokenTranscript('');
    setSpeechScore(null);

    if (currentEx.type === 'TRANSLATE_SENTENCE' || currentEx.type === 'ARRANGE_WORDS') {
      setSelectedWords([]);
      setAvailableWords([...(currentEx.options || [])]);
    }

    // Auto-play audio for listening exercises
    if (currentEx.type === 'LISTENING' && currentEx.audioText) {
      setTimeout(() => {
        audioService.speak(currentEx.audioText!, false);
      }, 350);
    }
  }, [currentEx, currentIndex]);

  if (!currentEx) {
    return null;
  }

  const progressPercent = Math.round((currentIndex / exercises.length) * 100);

  // Check if user has provided enough input to enable the Check button
  const canCheck = () => {
    if (feedbackState !== 'idle') return true;
    switch (currentEx.type) {
      case 'MULTIPLE_CHOICE':
      case 'LISTENING':
        return selectedChoice !== null;
      case 'TRANSLATE_SENTENCE':
      case 'ARRANGE_WORDS':
        return selectedWords.length > 0;
      case 'SPEAKING':
        return spokenTranscript.length > 0 || speechScore !== null;
      case 'MATCH_PAIRS':
        return matchedPairs.length === (currentEx.matchPairs?.length || 0) * 2;
      default:
        return false;
    }
  };

  // Check the answer
  const handleCheck = () => {
    if (feedbackState !== 'idle') {
      // Continue to next exercise or finish
      if (currentIndex + 1 < exercises.length) {
        setCurrentIndex((prev) => prev + 1);
      } else {
        const accuracy = Math.max(10, Math.round(((exercises.length - totalMistakes) / exercises.length) * 100));
        onCompleteLesson(accuracy);
      }
      return;
    }

    let isCorrect = false;
    let submittedAnswer = '';

    switch (currentEx.type) {
      case 'MULTIPLE_CHOICE':
      case 'LISTENING':
        submittedAnswer = selectedChoice || '';
        isCorrect = submittedAnswer.trim().toLowerCase() === currentEx.correctAnswer.trim().toLowerCase();
        break;

      case 'TRANSLATE_SENTENCE':
      case 'ARRANGE_WORDS':
        submittedAnswer = selectedWords.join(' ');
        isCorrect = submittedAnswer.trim().toLowerCase() === currentEx.correctAnswer.trim().toLowerCase();
        break;

      case 'SPEAKING':
        submittedAnswer = spokenTranscript;
        const score = calculateTextMatchScore(spokenTranscript, currentEx.correctAnswer);
        setSpeechScore(score);
        isCorrect = score >= 55; // Fair threshold for foreign learners
        break;

      case 'MATCH_PAIRS':
        isCorrect = matchedPairs.length === (currentEx.matchPairs?.length || 0) * 2;
        submittedAnswer = 'Matched all pairs';
        break;
    }

    if (isCorrect) {
      audioService.playCorrectSound();
      setFeedbackState('correct');
    } else {
      audioService.playWrongSound();
      setFeedbackState('wrong');
      setTotalMistakes((prev) => prev + 1);
      onLoseHeart();
      onLogMistake(currentEx, submittedAnswer || 'No answer');
    }
  };

  // Match pairs logic
  const handleSelectPairItem = (text: string, isEnglish: boolean) => {
    if (matchedPairs.includes(text) || feedbackState !== 'idle') return;

    if (isEnglish) {
      setPairSelectedEn(text);
      if (pairSelectedAr) {
        checkPairMatch(text, pairSelectedAr);
      }
    } else {
      setPairSelectedAr(text);
      if (pairSelectedEn) {
        checkPairMatch(pairSelectedEn, text);
      }
    }
  };

  const checkPairMatch = (en: string, ar: string) => {
    const pairs = currentEx.matchPairs || [];
    const found = pairs.some(([e, a]) => e === en && a === ar);

    if (found) {
      audioService.playCorrectSound();
      setMatchedPairs((prev) => [...prev, en, ar]);
      setPairSelectedEn(null);
      setPairSelectedAr(null);
    } else {
      audioService.playWrongSound();
      setMismatchedPair(true);
      setTimeout(() => {
        setMismatchedPair(false);
        setPairSelectedEn(null);
        setPairSelectedAr(null);
      }, 550);
    }
  };

  // Speech recording logic
  const toggleSpeechRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      // Browser fallback simulation if mic permission is denied or unsupported
      const simulatedText = currentEx.correctAnswer;
      setSpokenTranscript(simulatedText);
      setSpeechScore(100);
      return;
    }

    setIsRecording(true);
    setSpokenTranscript('');
    setSpeechScore(null);

    startSpeechListening(
      'en-US',
      (transcript) => {
        setSpokenTranscript(transcript);
        const score = calculateTextMatchScore(transcript, currentEx.correctAnswer);
        setSpeechScore(score);
        setIsRecording(false);
      },
      () => {
        setIsRecording(false);
      },
      () => {
        setIsRecording(false);
      }
    );
  };

  return (
    <div className="min-h-screen bg-[#131F24] flex flex-col justify-between text-white select-none">
      {/* Top Header */}
      <header className="px-4 py-3 border-b border-[#2A3A42] flex items-center justify-between gap-4 max-w-2xl mx-auto w-full">
        {/* Quit Button */}
        <button
          onClick={() => setShowQuitModal(true)}
          className="text-stone-400 hover:text-white p-1.5 rounded-xl hover:bg-[#1C2B32] transition-colors cursor-pointer"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Progress Bar */}
        <div className="flex-1 h-3.5 bg-[#2A3A42] rounded-full overflow-hidden p-0.5">
          <div
            className="h-full bg-gradient-to-r from-[#58CC02] to-[#6de305] rounded-full transition-all duration-300 shadow-inner"
            style={{ width: `${Math.max(5, progressPercent)}%` }}
          />
        </div>

        {/* Hearts */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#1C2B32] border border-[#2A3A42]">
          <Heart className="w-5 h-5 text-[#FF4B4B] fill-[#FF4B4B]" />
          <span className="font-extrabold text-sm text-[#FF4B4B] font-['Nunito',sans-serif]">
            {hearts}
          </span>
        </div>
      </header>

      {/* Main Exercise Viewport */}
      <main className="flex-1 max-w-xl mx-auto w-full px-4 py-6 flex flex-col justify-center">
        {/* Prompt Translation / Directive */}
        {currentEx.promptTranslation && (
          <div className="text-stone-400 text-xs font-bold mb-1 tracking-wide">
            {currentEx.promptTranslation}
          </div>
        )}

        {/* Main Question Title */}
        <div className="flex items-start gap-3 mb-6">
          {currentEx.audioText && (
            <button
              onClick={() => audioService.speak(currentEx.audioText!, false)}
              className="p-3 rounded-2xl bg-[#1CB0F6] hover:bg-[#159ed8] border-b-4 border-[#127fb0] active:translate-y-1 active:border-b-0 text-white cursor-pointer shadow-md shrink-0 transition-transform"
            >
              <Volume2 className="w-6 h-6" />
            </button>
          )}
          <h2 className="text-2xl font-black text-white leading-snug font-['Tajawal','Nunito',sans-serif]">
            {currentEx.question}
          </h2>
        </div>

        {/* 1. MULTIPLE CHOICE */}
        {currentEx.type === 'MULTIPLE_CHOICE' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentEx.options?.map((option, idx) => {
              const isSelected = selectedChoice === option;
              return (
                <button
                  key={idx}
                  onClick={() => feedbackState === 'idle' && setSelectedChoice(option)}
                  disabled={feedbackState !== 'idle'}
                  className={`p-4 rounded-2xl border-2 border-b-4 text-start font-bold text-base transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-[#1CB0F6]'
                      : 'bg-[#1C2B32] border-[#2A3A42] hover:border-stone-500 text-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>{option}</span>
                    <span className="w-6 h-6 rounded-lg bg-[#2A3A42] text-[11px] font-black flex items-center justify-center text-stone-400">
                      {idx + 1}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* 2. LISTENING */}
        {currentEx.type === 'LISTENING' && (
          <div className="space-y-6">
            <div className="flex items-center justify-center gap-4 py-4">
              <button
                onClick={() => audioService.speak(currentEx.audioText || '', false)}
                className="w-20 h-20 rounded-3xl bg-[#1CB0F6] hover:bg-[#189cdb] border-b-4 border-[#127fb0] active:translate-y-1 active:border-b-0 text-white flex items-center justify-center shadow-xl cursor-pointer"
              >
                <Volume2 className="w-10 h-10" />
              </button>
              <button
                onClick={() => audioService.speak(currentEx.audioText || '', true)}
                title={strings.slowAudio}
                className="w-14 h-14 rounded-2xl bg-[#1C2B32] border-2 border-b-4 border-[#2A3A42] hover:border-stone-400 active:translate-y-1 active:border-b-0 text-stone-300 flex items-center justify-center cursor-pointer"
              >
                <Volume1 className="w-6 h-6 text-[#FFC857]" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {currentEx.options?.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => feedbackState === 'idle' && setSelectedChoice(option)}
                  disabled={feedbackState !== 'idle'}
                  className={`p-4 rounded-2xl border-2 border-b-4 text-start font-bold text-base transition-all cursor-pointer ${
                    selectedChoice === option
                      ? 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-[#1CB0F6]'
                      : 'bg-[#1C2B32] border-[#2A3A42] hover:border-stone-500 text-white'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 3 & 4. TRANSLATE_SENTENCE & ARRANGE_WORDS */}
        {(currentEx.type === 'TRANSLATE_SENTENCE' || currentEx.type === 'ARRANGE_WORDS') && (
          <div className="space-y-6">
            {/* Selected Words Area (Sentence construction area) */}
            <div className="min-h-[72px] p-3 rounded-2xl bg-[#1C2B32]/60 border-2 border-dashed border-[#2A3A42] flex flex-wrap gap-2 items-center">
              {selectedWords.length === 0 ? (
                <span className="text-xs text-stone-500 font-bold px-2">
                  اضغط على الكلمات بالترتيب...
                </span>
              ) : (
                selectedWords.map((word, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      if (feedbackState !== 'idle') return;
                      // Remove word back to bank
                      setSelectedWords((prev) => prev.filter((_, i) => i !== idx));
                      setAvailableWords((prev) => [...prev, word]);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-[#1C2B32] border-2 border-b-4 border-[#2A3A42] hover:border-[#FF4B4B]/50 text-white font-bold text-sm shadow cursor-pointer active:scale-95 transition-all"
                  >
                    {word}
                  </button>
                ))
              )}
            </div>

            {/* Available Word Bank */}
            <div className="flex flex-wrap gap-2.5 justify-center">
              {availableWords.map((word, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    if (feedbackState !== 'idle') return;
                    setSelectedWords((prev) => [...prev, word]);
                    setAvailableWords((prev) => prev.filter((_, i) => i !== idx));
                  }}
                  className="px-4 py-2.5 rounded-xl bg-[#1C2B32] border-2 border-b-4 border-[#2A3A42] hover:border-stone-400 text-white font-bold text-sm shadow cursor-pointer active:translate-y-1 active:border-b-0 transition-all"
                >
                  {word}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 5. SPEAKING EXERCISE */}
        {currentEx.type === 'SPEAKING' && (
          <div className="flex flex-col items-center justify-center py-6 space-y-6">
            <div className="text-center">
              <span className="text-xs font-bold text-[#FFC857] uppercase tracking-wider block mb-1">
                {strings.repeatSentence}
              </span>
              <div className="flex items-center justify-center gap-3">
                <span className="text-2xl font-black text-white">{currentEx.correctAnswer}</span>
                <button
                  onClick={() => audioService.speak(currentEx.correctAnswer, false)}
                  className="p-2 rounded-xl bg-[#1CB0F6]/20 border border-[#1CB0F6]/40 text-[#1CB0F6] hover:bg-[#1CB0F6]/30 cursor-pointer"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Big Mic Button */}
            <button
              onClick={toggleSpeechRecording}
              className={`w-24 h-24 rounded-full flex items-center justify-center border-b-4 transition-all duration-300 shadow-2xl cursor-pointer ${
                isRecording
                  ? 'bg-[#FF4B4B] border-[#b92b2b] text-white animate-pulse ring-8 ring-[#FF4B4B]/30'
                  : 'bg-[#58CC02] hover:bg-[#48ab02] border-[#388501] text-white active:translate-y-1 active:border-b-0'
              }`}
            >
              {isRecording ? <Mic className="w-10 h-10 animate-bounce" /> : <Mic className="w-10 h-10" />}
            </button>

            <div className="text-center min-h-[48px]">
              {isRecording ? (
                <span className="text-sm font-bold text-[#FF4B4B] animate-pulse">
                  {strings.speakNow}
                </span>
              ) : spokenTranscript ? (
                <div>
                  <p className="text-xs text-stone-400 font-bold mb-1">صوتك المسجل:</p>
                  <p className="text-base font-extrabold text-[#58CC02]">"{spokenTranscript}"</p>
                  {speechScore !== null && (
                    <span className="text-xs font-bold text-stone-300 mt-1 inline-block">
                      دقة النطق: {speechScore}%
                    </span>
                  )}
                </div>
              ) : (
                <span className="text-xs text-stone-400 font-semibold">
                  {strings.tapToSpeak}
                </span>
              )}
            </div>
          </div>
        )}

        {/* 6. MATCH PAIRS */}
        {currentEx.type === 'MATCH_PAIRS' && (
          <div className="space-y-4">
            <p className="text-xs font-bold text-stone-400 text-center mb-2">
              {strings.matchThePairs}
            </p>
            <div className="grid grid-cols-2 gap-3">
              {/* English words column */}
              <div className="space-y-2">
                {currentEx.matchPairs?.map(([en], idx) => {
                  const isMatched = matchedPairs.includes(en);
                  const isSelected = pairSelectedEn === en;
                  return (
                    <button
                      key={`en_${idx}`}
                      onClick={() => handleSelectPairItem(en, true)}
                      disabled={isMatched || feedbackState !== 'idle'}
                      className={`w-full p-3.5 rounded-2xl border-2 border-b-4 font-bold text-sm text-center transition-all cursor-pointer ${
                        isMatched
                          ? 'bg-[#58CC02]/20 border-[#58CC02] text-[#58CC02] opacity-80 cursor-default'
                          : isSelected
                          ? 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-[#1CB0F6] scale-102'
                          : mismatchedPair && isSelected
                          ? 'bg-[#FF4B4B]/20 border-[#FF4B4B] text-[#FF4B4B]'
                          : 'bg-[#1C2B32] border-[#2A3A42] hover:border-stone-400 text-white'
                      }`}
                    >
                      {en}
                    </button>
                  );
                })}
              </div>

              {/* Arabic words column */}
              <div className="space-y-2">
                {currentEx.matchPairs?.map(([, ar], idx) => {
                  const isMatched = matchedPairs.includes(ar);
                  const isSelected = pairSelectedAr === ar;
                  return (
                    <button
                      key={`ar_${idx}`}
                      onClick={() => handleSelectPairItem(ar, false)}
                      disabled={isMatched || feedbackState !== 'idle'}
                      className={`w-full p-3.5 rounded-2xl border-2 border-b-4 font-bold text-sm text-center transition-all cursor-pointer ${
                        isMatched
                          ? 'bg-[#58CC02]/20 border-[#58CC02] text-[#58CC02] opacity-80 cursor-default'
                          : isSelected
                          ? 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-[#1CB0F6] scale-102'
                          : mismatchedPair && isSelected
                          ? 'bg-[#FF4B4B]/20 border-[#FF4B4B] text-[#FF4B4B]'
                          : 'bg-[#1C2B32] border-[#2A3A42] hover:border-stone-400 text-white'
                      }`}
                    >
                      {ar}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Bottom Sticky Feedback Bar (Duolingo Style Chunky Bar) */}
      <footer
        className={`w-full border-t-2 px-4 py-4 transition-all duration-300 ${
          feedbackState === 'correct'
            ? 'bg-[#1A3826] border-[#58CC02]'
            : feedbackState === 'wrong'
            ? 'bg-[#3A1B1F] border-[#FF4B4B]'
            : 'bg-[#131F24] border-[#2A3A42]'
        }`}
      >
        <div className="max-w-xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Feedback Info */}
          <div className="w-full sm:w-auto">
            {feedbackState === 'correct' && (
              <div className="flex items-center gap-2.5 text-[#58CC02]">
                <CheckCircle2 className="w-8 h-8 shrink-0" />
                <div>
                  <h4 className="font-black text-lg font-['Tajawal','Nunito',sans-serif]">
                    {strings.correct}
                  </h4>
                  <p className="text-xs text-green-200/90 font-bold">+15 XP</p>
                </div>
              </div>
            )}
            {feedbackState === 'wrong' && (
              <div className="flex items-start gap-2.5 text-[#FF4B4B]">
                <XCircle className="w-8 h-8 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-black text-base font-['Tajawal','Nunito',sans-serif]">
                    {strings.incorrect}
                  </h4>
                  <p className="text-xs text-stone-200 mt-0.5">
                    {strings.correctSolution}{' '}
                    <span className="font-bold text-white underline">
                      {currentEx.correctAnswer}
                    </span>
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Action Button */}
          <button
            onClick={handleCheck}
            disabled={!canCheck()}
            className={`w-full sm:w-48 py-3.5 px-6 rounded-2xl font-black text-base border-b-4 active:translate-y-1 active:border-b-0 cursor-pointer shadow-lg transition-all ${
              feedbackState === 'correct'
                ? 'bg-[#58CC02] hover:bg-[#46a302] border-[#378002] text-white'
                : feedbackState === 'wrong'
                ? 'bg-[#FF4B4B] hover:bg-[#e03a3a] border-[#b82626] text-white'
                : canCheck()
                ? 'bg-[#58CC02] hover:bg-[#46a302] border-[#378002] text-white'
                : 'bg-[#2A3A42] border-[#1C282F] text-stone-500 cursor-not-allowed opacity-60'
            }`}
          >
            {feedbackState === 'idle' ? strings.checkAnswer : strings.continueText}
          </button>
        </div>
      </footer>

      {/* Quit Lesson Confirmation Dialog */}
      {showQuitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-[#1C2B32] border-2 border-[#2A3A42] rounded-3xl p-6 shadow-2xl text-center">
            <h3 className="text-xl font-black text-white mb-2 font-['Tajawal','Nunito',sans-serif]">
              {strings.quitLesson}
            </h3>
            <p className="text-sm text-stone-300 mb-6 leading-relaxed">
              {strings.quitLessonConfirm}
            </p>
            <div className="space-y-2.5">
              <button
                onClick={() => setShowQuitModal(false)}
                className="w-full py-3.5 px-4 rounded-2xl font-black text-sm bg-[#58CC02] hover:bg-[#46A302] border-b-4 border-[#378002] text-white active:translate-y-1 active:border-b-0 cursor-pointer"
              >
                {strings.stay}
              </button>
              <button
                onClick={onQuitLesson}
                className="w-full py-2.5 px-4 rounded-2xl font-bold text-sm bg-transparent hover:bg-[#2A3A42] text-[#FF4B4B] cursor-pointer"
              >
                {strings.quit}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
