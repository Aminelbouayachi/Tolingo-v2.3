import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Flame, Gem, Award, Target } from 'lucide-react';
import { LocalizedStrings } from '../localization/strings';

interface LessonResultScreenProps {
  xpGained: number;
  gemsGained: number;
  accuracyPercent: number;
  streakDays: number;
  strings: LocalizedStrings;
  onContinue: () => void;
}

export const LessonResultScreen: React.FC<LessonResultScreenProps> = ({
  xpGained,
  gemsGained,
  accuracyPercent,
  streakDays,
  strings,
  onContinue,
}) => {
  useEffect(() => {
    // Launch celebratory confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#58CC02', '#FFC857', '#F26B3A', '#1CB0F6'],
      });
    } catch {
      // safe fallback
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#131F24] flex flex-col justify-between p-6 text-white select-none">
      <div className="max-w-md mx-auto w-full my-auto text-center space-y-6">
        {/* Animated Trophy / Mascot Celebration */}
        <div className="relative inline-block">
          <div className="w-28 h-28 mx-auto rounded-3xl bg-gradient-to-tr from-[#58CC02] to-[#46A302] border-4 border-[#378002] flex items-center justify-center text-5xl shadow-2xl animate-bounce">
            🎉
          </div>
          <div className="absolute -bottom-2 -end-2 w-10 h-10 rounded-full bg-[#FFC857] text-amber-950 font-black text-xs flex items-center justify-center border-2 border-[#131F24] shadow-md">
            +XP
          </div>
        </div>

        <div>
          <h2 className="text-3xl font-black text-white font-['Tajawal','Nunito',sans-serif]">
            {strings.lessonComplete}
          </h2>
          <p className="text-stone-300 text-sm mt-1">
            عمل رائع! تواصلك المستمر يصنع الفرق.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
          {/* XP Card */}
          <div className="p-4 rounded-2xl bg-[#1C2B32] border-2 border-[#2A3A42] flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#FFC857] text-xs font-bold mb-1">
              <Award className="w-4 h-4 fill-current" />
              <span>{strings.xpEarned}</span>
            </div>
            <span className="text-2xl font-black text-white font-['Nunito',sans-serif]">
              +{xpGained}
            </span>
          </div>

          {/* Gems Card */}
          <div className="p-4 rounded-2xl bg-[#1C2B32] border-2 border-[#2A3A42] flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#1CB0F6] text-xs font-bold mb-1">
              <Gem className="w-4 h-4 fill-current" />
              <span>{strings.gemsEarned}</span>
            </div>
            <span className="text-2xl font-black text-white font-['Nunito',sans-serif]">
              +{gemsGained}
            </span>
          </div>

          {/* Accuracy Card */}
          <div className="p-4 rounded-2xl bg-[#1C2B32] border-2 border-[#2A3A42] flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#58CC02] text-xs font-bold mb-1">
              <Target className="w-4 h-4" />
              <span>{strings.accuracy}</span>
            </div>
            <span className="text-2xl font-black text-white font-['Nunito',sans-serif]">
              {accuracyPercent}%
            </span>
          </div>

          {/* Streak Card */}
          <div className="p-4 rounded-2xl bg-[#1C2B32] border-2 border-[#2A3A42] flex flex-col items-center">
            <div className="flex items-center gap-1.5 text-[#FF9600] text-xs font-bold mb-1">
              <Flame className="w-4 h-4 fill-current" />
              <span>{strings.streak}</span>
            </div>
            <span className="text-2xl font-black text-white font-['Nunito',sans-serif]">
              {streakDays} 🔥
            </span>
          </div>
        </div>
      </div>

      {/* Continue Action */}
      <div className="max-w-md mx-auto w-full pt-4">
        <button
          onClick={onContinue}
          className="w-full py-4 px-6 rounded-2xl font-black text-base bg-[#58CC02] hover:bg-[#48ab02] border-b-4 border-[#378002] active:translate-y-1 active:border-b-0 text-white cursor-pointer shadow-xl transition-all"
        >
          {strings.continueText}
        </button>
      </div>
    </div>
  );
};
