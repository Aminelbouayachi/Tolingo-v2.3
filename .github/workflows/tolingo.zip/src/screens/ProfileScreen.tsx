import React from 'react';
import {
  Flame,
  Award,
  BookOpen,
  Target,
  Globe,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Snowflake,
  Volume2,
  Vibrate,
  Moon,
  ShieldCheck,
} from 'lucide-react';
import { UserProfile, AppLanguageCode, SUPPORTED_LANGUAGES } from '../types';
import { LocalizedStrings } from '../localization/strings';

interface ProfileScreenProps {
  userProfile: UserProfile;
  strings: LocalizedStrings;
  onLanguageSelected: (lang: AppLanguageCode) => void;
  onDailyGoalSelected: (minutes: number) => void;
  onToggleSound: (enabled: boolean) => void;
  onToggleHaptic: (enabled: boolean) => void;
  onToggleDarkMode: (enabled: boolean) => void;
  onOpenGitSync?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  userProfile,
  strings,
  onLanguageSelected,
  onDailyGoalSelected,
  onToggleSound,
  onToggleHaptic,
  onToggleDarkMode,
  onOpenGitSync,
}) => {
  // Calculate automatic time elapsed & mood state
  const lastStudy = userProfile.lastStudyTimestamp || Date.now();
  const elapsedMillis = Date.now() - lastStudy;
  const elapsedHours = Math.max(0, elapsedMillis / (1000 * 60 * 60));

  let moodState: 'HAPPY' | 'ANXIOUS' | 'FROZEN_SAD' = 'HAPPY';
  let moodTitle = 'سعيد وحماسي 😊🔥';
  let moodDesc = 'دخلتي فالوقت تقرى! الأيقونة والكائن نشيطان ومتحمسان.';
  let moodBadgeColor = 'bg-[#58CC02]/20 border-[#58CC02] text-[#58CC02]';

  if (elapsedHours > 30) {
    moodState = 'FROZEN_SAD';
    moodTitle = 'حزين ومتجمد 🥶💔';
    moodDesc = 'أكثر من 30 ساعة ديال الغياب! تجمدت الأيقونة وانفعل التطبيق لغيابك.';
    moodBadgeColor = 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-[#1CB0F6]';
  } else if (elapsedHours >= 24) {
    moodState = 'ANXIOUS';
    moodTitle = 'قلق ومترقب 😟⏳';
    moodDesc = 'تعطلتي شوية! مرّت 24 ساعة، والأيقونة بدأت بالتغير لتذكرك بالدراسة.';
    moodBadgeColor = 'bg-[#FF9600]/20 border-[#FF9600] text-[#FF9600]';
  }

  const dayLabels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

  return (
    <div className="min-h-screen bg-[#131F24] pb-28 text-white select-none">
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* User Card */}
        <div className="p-6 rounded-3xl bg-[#1C2B32] border border-[#2A3A42] flex items-center gap-4 shadow-xl">
          <div className="w-16 h-16 rounded-2xl bg-[#F26B3A]/20 border-2 border-[#F26B3A]/40 flex items-center justify-center text-4xl shadow-inner shrink-0">
            {userProfile.avatarEmoji}
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-black text-white font-['Tajawal','Nunito',sans-serif]">
              {userProfile.name}
            </h2>
            <p className="text-xs font-bold text-[#F26B3A] mt-0.5">
              دوري {userProfile.currentLeague} 🥈 • المرتبة #{userProfile.leagueRank}
            </p>
            <p className="text-[11px] text-stone-400 mt-0.5">
              {userProfile.email}
            </p>
          </div>
          {onOpenGitSync && (
            <button
              onClick={onOpenGitSync}
              className="p-2.5 rounded-2xl bg-[#2A3A42] hover:bg-[#374953] text-stone-200 transition-colors text-xs font-bold flex flex-col items-center gap-1 shrink-0"
              title="مزامنة GitHub"
            >
              <span className="text-base">🐙</span>
              <span className="text-[10px]">GitHub</span>
            </button>
          )}
        </div>

        {/* Direct APK Download Card (أحدث إصدار V1.0-9) */}
        <div className="p-5 rounded-3xl bg-gradient-to-br from-[#1C2B32] to-[#172D24] border-2 border-[#58CC02] shadow-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-[#58CC02] text-black">
              أحدث نسخة V1.0-9 جاهزة 🔥
            </span>
            <span className="text-xs font-mono font-bold text-[#58CC02]">21.8 MB</span>
          </div>
          <h3 className="text-base font-black text-white mb-1">
            تحميل أحدث إصدار Tolingo APK
          </h3>
          <p className="text-xs text-stone-300 mb-4 leading-relaxed">
            النسخة الجديدة تضم: مسار الدروس الدائري والنجمي 3D، نظام الغياب التلقائي (24h/30h)، امتحان تخطي الوحدات، ومترجم اللغات الكامل دون إنترنت.
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <a
              href="/Tolingo.apk"
              download="Tolingo.apk"
              className="flex-1 py-3 px-4 rounded-2xl bg-[#58CC02] hover:bg-[#46A302] text-black font-black text-center text-sm shadow-[0_4px_0_#46A302] active:translate-y-1 active:shadow-none transition-all flex items-center justify-center gap-2"
            >
              <span>📥 تحميل ملف APK المباشر</span>
            </a>
            <a
              href="https://github.com/Aminelbouayachi/Tolingo-v1/releases/tag/v1.0-9"
              target="_blank"
              rel="noreferrer"
              className="py-3 px-4 rounded-2xl bg-[#2A3A42] hover:bg-[#374953] text-white border border-[#3A4D58] font-bold text-center text-xs flex items-center justify-center gap-1.5"
            >
              <span>صفحة الإصدار v1.0-9 ↗</span>
            </a>
          </div>
        </div>

        {/* Automatic App Mood & Inactivity Card (طلب المستخدم بدقة) */}
        <div className="p-5 rounded-3xl bg-[#1C2B32] border-2 border-[#2A3A42] shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#FF9600]" />
              <h3 className="text-sm font-black text-white font-['Tajawal',sans-serif]">
                حالة التطبيق التلقائية (نظام الغياب الذكي)
              </h3>
            </div>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-black border ${moodBadgeColor}`}>
              {moodState === 'HAPPY' ? 'نشيط' : moodState === 'ANXIOUS' ? 'قلق' : 'متجمد'}
            </span>
          </div>

          {/* Current Mood Display */}
          <div className="p-3.5 rounded-2xl bg-[#131F24] border border-[#2A3A42] mb-4">
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="text-2xl">
                {moodState === 'HAPPY' ? '😊🔥' : moodState === 'ANXIOUS' ? '😟⏳' : '🥶💔'}
              </span>
              <div>
                <h4 className="text-sm font-black text-white">{moodTitle}</h4>
                <p className="text-[11px] text-stone-300 leading-snug">{moodDesc}</p>
              </div>
            </div>
            <div className="text-[10px] text-stone-400 font-bold mt-2 pt-2 border-t border-[#2A3A42] flex items-center justify-between">
              <span>الوقت المنقضي منذ آخر جلسة:</span>
              <span className="font-mono text-white">
                {elapsedHours < 1 ? 'أقل من ساعة' : `${elapsedHours.toFixed(1)} ساعة`}
              </span>
            </div>
          </div>

          {/* Visual Automatic Timeline (بدون تدخل المستخدم) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-stone-400">
              <span>المراحل التلقائية الثلاث:</span>
              <span className="text-[10px] text-stone-500">تلقائي باغ ديفو</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
              <div
                className={`p-2 rounded-xl border ${
                  moodState === 'HAPPY'
                    ? 'bg-[#58CC02]/20 border-[#58CC02] text-[#58CC02] font-black'
                    : 'bg-[#131F24] border-[#2A3A42] text-stone-400'
                }`}
              >
                <div className="text-sm mb-0.5">🟢</div>
                <div className="font-bold">0 إلى 24 ساعة</div>
                <div className="text-[9px] opacity-80">سعيد فالوقت</div>
              </div>
              <div
                className={`p-2 rounded-xl border ${
                  moodState === 'ANXIOUS'
                    ? 'bg-[#FF9600]/20 border-[#FF9600] text-[#FF9600] font-black'
                    : 'bg-[#131F24] border-[#2A3A42] text-stone-400'
                }`}
              >
                <div className="text-sm mb-0.5">🟡</div>
                <div className="font-bold">+24 ساعة ودقيقة</div>
                <div className="text-[9px] opacity-80">قلق وتغير الأيقونة</div>
              </div>
              <div
                className={`p-2 rounded-xl border ${
                  moodState === 'FROZEN_SAD'
                    ? 'bg-[#1CB0F6]/20 border-[#1CB0F6] text-[#1CB0F6] font-black'
                    : 'bg-[#131F24] border-[#2A3A42] text-stone-400'
                }`}
              >
                <div className="text-sm mb-0.5">🔵</div>
                <div className="font-bold">+30 ساعة غياب</div>
                <div className="text-[9px] opacity-80">تجميد الأيقونة وانفعال</div>
              </div>
            </div>
          </div>
        </div>

        {/* Statistics Grid */}
        <div>
          <h3 className="text-sm font-black text-stone-300 mb-3 font-['Tajawal',sans-serif]">
            {strings.stats}
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-[#1C2B32] border border-[#2A3A42]">
              <div className="flex items-center gap-2 text-stone-400 text-xs font-bold mb-1">
                <Flame className="w-4 h-4 text-[#FF9600]" />
                <span>{strings.dayStreak}</span>
              </div>
              <div className="text-2xl font-black text-white font-['Nunito',sans-serif]">
                {userProfile.streakDays} 🔥
              </div>
              <div className="text-[10px] text-stone-400 mt-0.5">{strings.streakDays} متتالية</div>
            </div>

            <div className="p-4 rounded-2xl bg-[#1C2B32] border border-[#2A3A42]">
              <div className="flex items-center gap-2 text-stone-400 text-xs font-bold mb-1">
                <Award className="w-4 h-4 text-[#FFC857]" />
                <span>{strings.totalXp}</span>
              </div>
              <div className="text-2xl font-black text-white font-['Nunito',sans-serif]">
                {userProfile.xp} ⭐
              </div>
              <div className="text-[10px] text-stone-400 mt-0.5">نقاط الخبرة</div>
            </div>

            <div className="p-4 rounded-2xl bg-[#1C2B32] border border-[#2A3A42]">
              <div className="flex items-center gap-2 text-stone-400 text-xs font-bold mb-1">
                <BookOpen className="w-4 h-4 text-[#1CB0F6]" />
                <span>{strings.wordsLearned}</span>
              </div>
              <div className="text-2xl font-black text-white font-['Nunito',sans-serif]">
                {userProfile.totalWordsLearned}
              </div>
              <div className="text-[10px] text-stone-400 mt-0.5">كلمات مكتسبة</div>
            </div>

            <div className="p-4 rounded-2xl bg-[#1C2B32] border border-[#2A3A42]">
              <div className="flex items-center gap-2 text-stone-400 text-xs font-bold mb-1">
                <Target className="w-4 h-4 text-[#58CC02]" />
                <span>{strings.accuracy}</span>
              </div>
              <div className="text-2xl font-black text-white font-['Nunito',sans-serif]">
                {userProfile.totalAccuracyPercent}%
              </div>
              <div className="text-[10px] text-stone-400 mt-0.5">معدل الدقة</div>
            </div>
          </div>
        </div>

        {/* Streak Weekly Calendar */}
        <div className="p-5 rounded-3xl bg-[#1C2B32] border border-[#2A3A42] shadow-sm">
          <h3 className="text-sm font-black text-white mb-3">
            {strings.streakCalendar}
          </h3>
          <div className="flex items-center justify-between">
            {dayLabels.map((label, idx) => {
              const dayNum = idx + 1;
              const isActive = userProfile.activityDaysThisWeek.includes(dayNum);
              return (
                <div key={idx} className="flex flex-col items-center gap-1.5">
                  <span className="text-[11px] font-bold text-stone-400">{label}</span>
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-black transition-colors ${
                      isActive
                        ? 'bg-[#FF9600] text-white shadow-md'
                        : 'bg-[#131F24] border border-[#2A3A42] text-stone-500'
                    }`}
                  >
                    {isActive ? '🔥' : '•'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* App Language Selector */}
        <div className="p-5 rounded-3xl bg-[#1C2B32] border border-[#2A3A42]">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-4 h-4 text-[#F26B3A]" />
            <h3 className="text-sm font-black text-white">{strings.appLanguage}</h3>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {(['ar', 'fr', 'en'] as AppLanguageCode[]).map((code) => {
              const isSelected = userProfile.nativeLanguage === code;
              return (
                <button
                  key={code}
                  onClick={() => onLanguageSelected(code)}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#F26B3A]/20 border-[#F26B3A] text-white font-bold'
                      : 'bg-[#131F24] border-[#2A3A42] text-stone-300 hover:border-stone-400'
                  }`}
                >
                  <div className="text-xl mb-0.5">{SUPPORTED_LANGUAGES[code].flag}</div>
                  <div className="text-xs">{SUPPORTED_LANGUAGES[code].displayName}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Daily Goal */}
        <div className="p-5 rounded-3xl bg-[#1C2B32] border border-[#2A3A42]">
          <h3 className="text-sm font-black text-white mb-3">{strings.dailyGoal}</h3>
          <div className="grid grid-cols-3 gap-2">
            {[5, 10, 15].map((mins) => {
              const isSelected = userProfile.dailyGoalMinutes === mins;
              return (
                <button
                  key={mins}
                  onClick={() => onDailyGoalSelected(mins)}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#FFC857]/20 border-[#FFC857] text-[#FFC857] font-bold'
                      : 'bg-[#131F24] border-[#2A3A42] text-stone-300 hover:border-stone-400'
                  }`}
                >
                  <div className="text-base font-black font-['Nunito',sans-serif]">
                    {mins} min
                  </div>
                  <div className="text-[10px] text-stone-400">
                    {mins === 5 ? 'خفيف' : mins === 10 ? 'عادي' : 'جاد'}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Preferences Toggles */}
        <div className="p-5 rounded-3xl bg-[#1C2B32] border border-[#2A3A42] space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Volume2 className="w-5 h-5 text-[#F26B3A]" />
              <span className="text-sm font-bold text-white">{strings.soundEffects}</span>
            </div>
            <input
              type="checkbox"
              checked={userProfile.soundEffectsEnabled}
              onChange={(e) => onToggleSound(e.target.checked)}
              className="w-5 h-5 accent-[#F26B3A] cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Vibrate className="w-5 h-5 text-[#F26B3A]" />
              <span className="text-sm font-bold text-white">{strings.hapticFeedback}</span>
            </div>
            <input
              type="checkbox"
              checked={userProfile.hapticEnabled}
              onChange={(e) => onToggleHaptic(e.target.checked)}
              className="w-5 h-5 accent-[#F26B3A] cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Moon className="w-5 h-5 text-[#F26B3A]" />
              <span className="text-sm font-bold text-white">{strings.darkMode}</span>
            </div>
            <input
              type="checkbox"
              checked={userProfile.darkMode}
              onChange={(e) => onToggleDarkMode(e.target.checked)}
              className="w-5 h-5 accent-[#F26B3A] cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
