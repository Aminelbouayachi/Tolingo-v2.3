import { AppLanguageCode } from '../types';

export interface LocalizedStrings {
  appName: string;
  tagline: string;
  startLearning: string;
  alreadyHaveAccount: string;
  continueText: string;
  checkAnswer: string;
  correct: string;
  incorrect: string;
  correctSolution: string;
  excellent: string;
  awesome: string;
  tapToSpeak: string;
  listening: string;
  speakNow: string;
  speechNotDetected: string;
  tapToListen: string;
  slowAudio: string;
  matchThePairs: string;
  translateThisSentence: string;
  arrangeTheWords: string;
  chooseCorrectOption: string;
  listenAndChoose: string;
  repeatSentence: string;
  unit: string;
  lesson: string;
  startLesson: string;
  reviewLesson: string;
  locked: string;
  chestReward: string;
  claimReward: string;
  hearts: string;
  outOfHearts: string;
  refillHearts: string;
  refillWithGems: string;
  practiceToRefill: string;
  nextHeartIn: string;
  streak: string;
  streakDays: string;
  dayStreak: string;
  streakFreeze: string;
  gems: string;
  xp: string;
  totalXp: string;
  league: string;
  leaderboard: string;
  promotionZone: string;
  demotionZone: string;
  daysLeft: string;
  reviewMistakes: string;
  noMistakesYet: string;
  practiceMistakesToEarnHearts: string;
  profile: string;
  stats: string;
  wordsLearned: string;
  lessonsCompleted: string;
  accuracy: string;
  streakCalendar: string;
  settings: string;
  appLanguage: string;
  courseLanguage: string;
  dailyGoal: string;
  soundEffects: string;
  hapticFeedback: string;
  darkMode: string;
  dailyReminder: string;
  testReminder: string;
  reminderSent: string;
  quitLesson: string;
  quitLessonConfirm: string;
  quit: string;
  stay: string;
  lessonComplete: string;
  xpEarned: string;
  gemsEarned: string;
  casualGoal: string;
  regularGoal: string;
  seriousGoal: string;
  minutesPerDay: string;
  selectCourse: string;
  englishCourse: string;
  frenchCourse: string;
  spanishCourse: string;
  // Extra UI helpers
  jumpToLessonTitle: string;
  jumpToLessonPrompt: string;
  jumpToLessonConfirm: string;
  cancel: string;
  openMistakesReview: string;
  mistakesBadgeText: string;
  gitSyncTitle: string;
  gitSyncDescription: string;
  commitAndPush: string;
  syncSuccess: string;
}

export const StringsAr: LocalizedStrings = {
  appName: 'تولينغو',
  tagline: 'تعلم بالتحدث',
  startLearning: 'ابدأ التعلم الآن',
  alreadyHaveAccount: 'لدي حساب بالفعل',
  continueText: 'متابعة',
  checkAnswer: 'تحقق من الإجابة',
  correct: 'عمل ممتاز ورائع!',
  incorrect: 'إجابة غير دقيقة',
  correctSolution: 'الحل الصحيح:',
  excellent: 'ممتاز!',
  awesome: 'مذهل!',
  tapToSpeak: 'اضغط على الميكروفون للتحدث',
  listening: 'جارٍ الاستماع إليك...',
  speakNow: 'تحدث الآن بوضوح...',
  speechNotDetected: 'لم نتمكن من التقاط صوتك بوضوح. أعد المحاولة.',
  tapToListen: 'اضغط للاستماع',
  slowAudio: 'بطيء',
  matchThePairs: 'طابق الكلمات المترادفة',
  translateThisSentence: 'ترجم هذه الجملة',
  arrangeTheWords: 'رتب الكلمات لتكوين الجملة',
  chooseCorrectOption: 'اختر الترجمة الصحيحة',
  listenAndChoose: 'استمع بدقة واختر الإجابة الصحيحة',
  repeatSentence: 'انطق هذه الجملة بصوت واضح',
  unit: 'الوحدة',
  lesson: 'الدرس',
  startLesson: 'ابدأ',
  reviewLesson: 'مراجعة',
  locked: 'مغلق',
  chestReward: 'صندوق مكافأة إتمام الوحدة!',
  claimReward: 'فتح الصندوق واستلام الجواهر',
  hearts: 'القلوب',
  outOfHearts: 'نفدت قلوبك!',
  refillHearts: 'إعادة تعبئة القلوب',
  refillWithGems: 'تعبئة القلوب بـ 50 جوهرة',
  practiceToRefill: 'تدرب على الأخطاء (+1 قلب)',
  nextHeartIn: 'القلب القادم خلال',
  streak: 'الحماسة',
  streakDays: 'أيام',
  dayStreak: 'أيام حماسة متتالية',
  streakFreeze: 'تجميد الحماسة',
  gems: 'الجواهر',
  xp: 'الخبرة',
  totalXp: 'مجموع نقاط الخبرة',
  league: 'الدوري',
  leaderboard: 'لوحة المتصدرين',
  promotionZone: 'منطقة الترقية إلى الدوري الأعلى ⬆️',
  demotionZone: 'منطقة الهبوط ⬇️',
  daysLeft: 'أيام متبقية',
  reviewMistakes: 'سجل الأخطاء والمراجعة التراكمية',
  noMistakesYet: 'رائع! لا توجد أخطاء حالياً. واصل التعلم.',
  practiceMistakesToEarnHearts: 'راجع أخطاءك السابقة لاستعادة القلوب وكسب نقاط خبرة إضافية',
  profile: 'الملف الشخصي',
  stats: 'الإحصائيات',
  wordsLearned: 'الكلمات المكتسبة',
  lessonsCompleted: 'الدروس المكتملة',
  accuracy: 'دقة الإجابات',
  streakCalendar: 'نشاطك الحماسي الأسبوعي',
  settings: 'الإعدادات والخيارات',
  appLanguage: 'لغة التطبيق',
  courseLanguage: 'اللغة المتعلمة',
  dailyGoal: 'الهدف اليومي المفضل',
  soundEffects: 'المؤثرات الصوتية والنغمات',
  hapticFeedback: 'الاهتزاز والتفاعل اللمسي',
  darkMode: 'الوضع الليلي الداكن',
  dailyReminder: 'تنبيه الدراسة اليومي',
  testReminder: 'إرسال إشعار تجريبي فوري',
  reminderSent: 'تم إرسال إشعار التذكير بنجاح!',
  quitLesson: 'مغادرة الدرس الحالي؟',
  quitLessonConfirm: 'هل أنت متأكد؟ ستفقد تقدمك في هذا الدرس إذا غادرت.',
  quit: 'مغادرة',
  stay: 'مواصلة الدرس',
  lessonComplete: 'اكتمل الدرس بنجاح باهر!',
  xpEarned: 'نقاط الخبرة XP',
  gemsEarned: 'الجواهر المكتسبة',
  casualGoal: 'خفيف (5 دقائق)',
  regularGoal: 'عادي (10 دقائق)',
  seriousGoal: 'مكثف (15 دقيقة)',
  minutesPerDay: 'دقيقة / يوم',
  selectCourse: 'اختر المسار التعليمي',
  englishCourse: 'الإنجليزية للمتحدثين بالعربية',
  frenchCourse: 'الفرنسية',
  spanishCourse: 'الإسبانية',
  jumpToLessonTitle: 'القفز إلى هنا؟ ⏩',
  jumpToLessonPrompt: 'هل ترغب في تجاوز الترتيب والبدء مباشرة في هذا الدرس؟',
  jumpToLessonConfirm: 'نعم، ابدأ الآن 🚀',
  cancel: 'إلغاء',
  openMistakesReview: 'راجع أخطاءك السابقة واستعد قلوبك',
  mistakesBadgeText: 'أخطاء تحتاج للمراجعة',
  gitSyncTitle: 'إدارة المستودع و GitHub Token',
  gitSyncDescription: 'التوكن والمستودع Tolingo-v1 متصلان وجاهزان لتسجيل التغييرات.',
  commitAndPush: 'حفظ وتحديث المستودع على GitHub',
  syncSuccess: 'تم مزامنة التغييرات بنجاح مع GitHub!',
};

export const StringsFr: LocalizedStrings = {
  appName: 'Tolingo',
  tagline: 'Apprends en parlant',
  startLearning: 'Commencer',
  alreadyHaveAccount: "J'ai déjà un compte",
  continueText: 'Continuer',
  checkAnswer: 'Vérifier',
  correct: 'Excellent travail !',
  incorrect: 'Pas tout à fait',
  correctSolution: 'Bonne réponse :',
  excellent: 'Excellent !',
  awesome: 'Génial !',
  tapToSpeak: 'Appuie sur le micro pour parler',
  listening: 'Écoute en cours...',
  speakNow: 'Parle maintenant...',
  speechNotDetected: 'Son non reconnu. Réessaie ou valide.',
  tapToListen: 'Appuie pour écouter',
  slowAudio: 'Lent',
  matchThePairs: 'Associe les paires',
  translateThisSentence: 'Traduis cette phrase',
  arrangeTheWords: "Remets les mots dans l'ordre",
  chooseCorrectOption: 'Choisis la bonne traduction',
  listenAndChoose: 'Écoute et choisis la bonne réponse',
  repeatSentence: 'Prononce cette phrase clairement',
  unit: 'Unité',
  lesson: 'Leçon',
  startLesson: 'DÉBUTER',
  reviewLesson: 'RÉVISER',
  locked: 'Verrouillé',
  chestReward: 'Coffre bonus débloqué !',
  claimReward: 'Ouvrir le coffre (+30 Gemmes)',
  hearts: 'Vies',
  outOfHearts: 'Plus de vies !',
  refillHearts: 'Recharger les vies',
  refillWithGems: 'Recharger pour 50 gemmes',
  practiceToRefill: "S'entraîner sur les erreurs (+1 vie)",
  nextHeartIn: 'Prochaine vie dans',
  streak: 'Série',
  streakDays: 'jours',
  dayStreak: 'Série de jours',
  streakFreeze: 'Gel de série',
  gems: 'Gemmes',
  xp: 'XP',
  totalXp: 'XP Total',
  league: 'Ligue',
  leaderboard: 'Classement',
  promotionZone: 'Zone de promotion ⬆️',
  demotionZone: 'Zone de relégation ⬇️',
  daysLeft: 'jours restants',
  reviewMistakes: 'Gestion des erreurs',
  noMistakesYet: 'Aucune erreur pour le moment ! Continue ainsi.',
  practiceMistakesToEarnHearts: 'Révise tes erreurs pour regagner des vies et des XP',
  profile: 'Profil',
  stats: 'Statistiques',
  wordsLearned: 'Mots appris',
  lessonsCompleted: 'Terminées',
  accuracy: 'Précision',
  streakCalendar: 'Activité de la série',
  settings: 'Paramètres',
  appLanguage: "Langue de l'application",
  courseLanguage: 'Langue cible',
  dailyGoal: 'Objectif quotidien',
  soundEffects: 'Effets sonores',
  hapticFeedback: 'Retour haptique',
  darkMode: 'Mode sombre',
  dailyReminder: 'Rappel quotidien',
  testReminder: 'Tester la notification',
  reminderSent: 'Notification de rappel envoyée !',
  quitLesson: 'Quitter la leçon ?',
  quitLessonConfirm: 'Es-tu sûr ? Tout progrès dans cette leçon sera perdu.',
  quit: 'Quitter',
  stay: 'Continuer',
  lessonComplete: 'Leçon terminée avec succès !',
  xpEarned: 'XP gagnés',
  gemsEarned: 'Gemmes gagnées',
  casualGoal: 'Tranquille (5 min)',
  regularGoal: 'Régulier (10 min)',
  seriousGoal: 'Intensif (15 min)',
  minutesPerDay: 'min / jour',
  selectCourse: 'Choisir le cours',
  englishCourse: 'Anglais pour arabophones',
  frenchCourse: 'Français',
  spanishCourse: 'Espagnol',
  jumpToLessonTitle: 'Sauter jusqu’ici ? ⏩',
  jumpToLessonPrompt: 'Veux-tu débloquer et commencer directement cette leçon ?',
  jumpToLessonConfirm: 'Oui, commencer 🚀',
  cancel: 'Annuler',
  openMistakesReview: 'Révise tes erreurs et recharge tes cœurs',
  mistakesBadgeText: 'Erreurs à réviser',
  gitSyncTitle: 'Dépôt & GitHub Token',
  gitSyncDescription: 'Le jeton GitHub est prêt pour valider et pousser les modifications.',
  commitAndPush: 'Enregistrer et pousser sur GitHub',
  syncSuccess: 'Synchronisé avec succès sur GitHub !',
};

export const StringsEn: LocalizedStrings = {
  appName: 'Tolingo',
  tagline: 'Learn by speaking',
  startLearning: 'Get Started',
  alreadyHaveAccount: 'I already have an account',
  continueText: 'Continue',
  checkAnswer: 'Check',
  correct: 'Great job!',
  incorrect: 'Not quite right',
  correctSolution: 'Correct answer:',
  excellent: 'Excellent!',
  awesome: 'Awesome!',
  tapToSpeak: 'Tap microphone to speak',
  listening: 'Listening...',
  speakNow: 'Speak now...',
  speechNotDetected: 'Could not hear clearly. Try again or check mic.',
  tapToListen: 'Tap to listen',
  slowAudio: 'Slow',
  matchThePairs: 'Match the pairs',
  translateThisSentence: 'Translate this sentence',
  arrangeTheWords: 'Arrange the words in order',
  chooseCorrectOption: 'Choose the correct option',
  listenAndChoose: 'Listen and choose what you hear',
  repeatSentence: 'Pronounce this sentence clearly',
  unit: 'Unit',
  lesson: 'Lesson',
  startLesson: 'START',
  reviewLesson: 'REVIEW',
  locked: 'Locked',
  chestReward: 'Milestone Chest Unlocked!',
  claimReward: 'Open Chest (+30 Gems)',
  hearts: 'Hearts',
  outOfHearts: 'Out of hearts!',
  refillHearts: 'Refill Hearts',
  refillWithGems: 'Refill for 50 gems',
  practiceToRefill: 'Practice mistakes (+1 heart)',
  nextHeartIn: 'Next heart in',
  streak: 'Streak',
  streakDays: 'days',
  dayStreak: 'Day Streak',
  streakFreeze: 'Streak Freeze',
  gems: 'Gems',
  xp: 'XP',
  totalXp: 'Total XP',
  league: 'League',
  leaderboard: 'Leaderboard',
  promotionZone: 'Promotion Zone ⬆️',
  demotionZone: 'Demotion Zone ⬇️',
  daysLeft: 'days left',
  reviewMistakes: 'Mistakes Review',
  noMistakesYet: 'No mistakes right now! Keep it up.',
  practiceMistakesToEarnHearts: 'Practice mistakes to refill hearts and gain XP',
  profile: 'Profile',
  stats: 'Statistics',
  wordsLearned: 'Words Learned',
  lessonsCompleted: 'Completed',
  accuracy: 'Accuracy',
  streakCalendar: 'Streak Calendar',
  settings: 'Settings',
  appLanguage: 'App Language',
  courseLanguage: 'Course Language',
  dailyGoal: 'Daily Goal',
  soundEffects: 'Sound Effects',
  hapticFeedback: 'Haptic Feedback',
  darkMode: 'Dark Mode',
  dailyReminder: 'Daily Reminder',
  testReminder: 'Send Test Reminder',
  reminderSent: 'Reminder notification simulated!',
  quitLesson: 'Quit lesson?',
  quitLessonConfirm: 'Are you sure? All progress in this lesson will be lost.',
  quit: 'Quit',
  stay: 'Keep Learning',
  lessonComplete: 'Lesson Completed!',
  xpEarned: 'XP Earned',
  gemsEarned: 'Gems Earned',
  casualGoal: 'Casual (5 min)',
  regularGoal: 'Regular (10 min)',
  seriousGoal: 'Serious (15 min)',
  minutesPerDay: 'min / day',
  selectCourse: 'Select Course',
  englishCourse: 'English for Arabic Speakers',
  frenchCourse: 'French',
  spanishCourse: 'Spanish',
  jumpToLessonTitle: 'Jump to here? ⏩',
  jumpToLessonPrompt: 'Do you want to unlock and start directly at this lesson?',
  jumpToLessonConfirm: 'Yes, start now 🚀',
  cancel: 'Cancel',
  openMistakesReview: 'Review previous mistakes to earn hearts',
  mistakesBadgeText: 'Mistakes to review',
  gitSyncTitle: 'Repository & GitHub Token',
  gitSyncDescription: 'The GitHub token is connected and ready to commit/push changes.',
  commitAndPush: 'Commit & Push to GitHub',
  syncSuccess: 'Successfully pushed to GitHub repository!',
};

export function getStrings(lang: AppLanguageCode): LocalizedStrings {
  switch (lang) {
    case 'ar':
      return StringsAr;
    case 'fr':
      return StringsFr;
    case 'en':
    default:
      return StringsEn;
  }
}
