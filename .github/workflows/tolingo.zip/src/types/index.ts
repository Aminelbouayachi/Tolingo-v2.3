export type AppLanguageCode = 'ar' | 'fr' | 'en';

export interface AppLanguage {
  code: AppLanguageCode;
  displayName: string;
  flag: string;
  isRtl: boolean;
}

export const SUPPORTED_LANGUAGES: Record<AppLanguageCode, AppLanguage> = {
  ar: { code: 'ar', displayName: 'العربية', flag: '🇸🇦', isRtl: true },
  fr: { code: 'fr', displayName: 'Français', flag: '🇫🇷', isRtl: false },
  en: { code: 'en', displayName: 'English', flag: '🇬🇧', isRtl: false },
};

export type ExerciseType =
  | 'MULTIPLE_CHOICE'
  | 'TRANSLATE_SENTENCE'
  | 'ARRANGE_WORDS'
  | 'LISTENING'
  | 'SPEAKING'
  | 'MATCH_PAIRS';

export type LessonNodeType = 'STAR' | 'LISTENING' | 'PRACTICE' | 'STORY' | 'EXAM';

export interface Exercise {
  id: string;
  type: ExerciseType;
  question: string;
  promptTranslation?: string;
  options?: string[];
  correctAnswer: string;
  targetWords?: string[];
  audioText?: string | null;
  matchPairs?: [string, string][];
  explanation?: string;
}

export interface LessonModel {
  id: string;
  unitId: string;
  lessonNumber: number;
  title: string;
  isCompleted: boolean;
  isLocked: boolean;
  isExam: boolean;
  nodeType: LessonNodeType;
  exercises: Exercise[];
  xpReward: number;
  gemReward: number;
}

export interface UnitModel {
  id: string;
  unitNumber: number;
  title: string;
  description: string;
  sectionNumber: number;
  sectionTitle: string;
  grammarTip: string;
  lessons: LessonModel[];
  bonusChestClaimed: boolean;
  bonusGems: number;
}

export interface Course {
  id: string;
  title: string;
  targetLanguage: string;
  sourceLanguage: string;
  flag: string;
  units: UnitModel[];
}

export type LeagueTier = 'BRONZE' | 'SILVER' | 'GOLD' | 'OBSIDIAN' | 'DIAMOND';

export interface LeagueTierInfo {
  tier: LeagueTier;
  displayName: string;
  badge: string;
  minXp: number;
  color: string;
}

export const LEAGUE_TIERS: Record<LeagueTier, LeagueTierInfo> = {
  BRONZE: { tier: 'BRONZE', displayName: 'Bronze', badge: '🥉', minXp: 0, color: '#CD7F32' },
  SILVER: { tier: 'SILVER', displayName: 'Silver', badge: '🥈', minXp: 200, color: '#C0C0C0' },
  GOLD: { tier: 'GOLD', displayName: 'Gold', badge: '🥇', minXp: 500, color: '#FFD700' },
  OBSIDIAN: { tier: 'OBSIDIAN', displayName: 'Obsidian', badge: '🔮', minXp: 1000, color: '#9B51E0' },
  DIAMOND: { tier: 'DIAMOND', displayName: 'Diamond', badge: '💎', minXp: 2000, color: '#00D2D3' },
};

export interface LeaderboardEntry {
  id: string;
  name: string;
  avatarEmoji: string;
  xp: number;
  isCurrentUser?: boolean;
  rank: number;
  isPromotionZone?: boolean;
  isDemotionZone?: boolean;
}

export interface MistakeItem {
  id: string;
  exerciseId: string;
  question: string;
  promptTranslation: string;
  correctAnswer: string;
  userAnswer?: string;
  timestamp: number;
  timesPracticed?: number;
  isMastered?: boolean;
}

export type AppMoodState = 'HAPPY' | 'ANXIOUS' | 'FROZEN_SAD';

export interface UserProfile {
  name: string;
  email: string;
  avatarEmoji: string;
  nativeLanguage: AppLanguageCode;
  currentCourseId: string;
  dailyGoalMinutes: number;
  xp: number;
  streakDays: number;
  streakActiveToday: boolean;
  hearts: number;
  maxHearts: number;
  gems: number;
  currentLeague: LeagueTier;
  leagueRank: number;
  totalWordsLearned: number;
  completedLessonsCount: number;
  totalAccuracyPercent: number;
  activityDaysThisWeek: number[]; // 1 to 7 (Mon=1 ... Sun=7)
  soundEffectsEnabled: boolean;
  hapticEnabled: boolean;
  darkMode: boolean;
  reminderHour: number;
  reminderMinute: number;
  reminderEnabled: boolean;
  isOnboarded: boolean;
  lastStudyTimestamp: number;
}

export type NavDestination = 'LEARN' | 'MISTAKES' | 'LEADERBOARD' | 'PROFILE' | 'TRANSLATE';

// Offline Language Pack Models
export interface OfflineLanguagePack {
  id: string;
  name: string;
  sourceLang: string;
  targetLang: string;
  sourceFlag: string;
  targetFlag: string;
  sizeMb: number;
  vocabularyCount: number;
  isDownloaded: boolean;
  downloadProgress: number; // 0 to 100
  downloadDate?: string;
}

export interface OfflineTranslationEntry {
  sourceText: string;
  translatedText: string;
  pronunciation?: string;
  category?: string;
}
