/**
 * Tolingo Web Speech Recognition Service
 * Handles microphone listening and compares spoken words against target phrases.
 */

// Define SpeechRecognition interface for TypeScript
interface IWindowSpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
}

interface SpeechRecognitionEvent {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
        confidence: number;
      };
    };
  };
}

declare global {
  interface Window {
    SpeechRecognition?: { new (): IWindowSpeechRecognition };
    webkitSpeechRecognition?: { new (): IWindowSpeechRecognition };
  }
}

export function isSpeechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

export function startSpeechListening(
  targetLang = 'en-US',
  onResult: (transcript: string, isFinal: boolean) => void,
  onError: (err: string) => void,
  onEnd: () => void
): (() => void) | null {
  if (!isSpeechRecognitionSupported()) {
    onError('Browser does not support Speech Recognition');
    return null;
  }

  const SpeechRecognitionClass = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognitionClass) return null;

  try {
    const recognition = new SpeechRecognitionClass();
    recognition.lang = targetLang;
    recognition.interimResults = true;
    recognition.continuous = false;

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const result = event.results[0]?.[0];
      if (result) {
        onResult(result.transcript, true);
      }
    };

    recognition.onerror = (event: { error: string }) => {
      onError(event.error);
    };

    recognition.onend = () => {
      onEnd();
    };

    recognition.start();

    return () => {
      try {
        recognition.stop();
      } catch {
        // Ignored
      }
    };
  } catch (e) {
    onError((e as Error).message);
    return null;
  }
}

/**
 * Calculates similarity between spoken text and target text (0 to 100%)
 */
export function calculateTextMatchScore(spoken: string, target: string): number {
  const clean = (s: string) =>
    s
      .toLowerCase()
      .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?'"؛،!؟]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

  const s1 = clean(spoken);
  const s2 = clean(target);

  if (s1 === s2) return 100;
  if (!s1 || !s2) return 0;

  const w1 = s1.split(' ');
  const w2 = s2.split(' ');

  let matches = 0;
  w2.forEach((word) => {
    if (w1.includes(word)) {
      matches++;
    }
  });

  const precision = (matches / Math.max(w1.length, w2.length)) * 100;
  return Math.min(100, Math.round(precision));
}
