import { OfflineLanguagePack, OfflineTranslationEntry } from '../types';

export interface SupportedTranslationLanguage {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  isRtl: boolean;
  packId?: string;
  hasOfflinePack: boolean;
}

export const ALL_TRANSLATION_LANGUAGES: SupportedTranslationLanguage[] = [
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦', isRtl: true, packId: 'pack_ar_en', hasOfflinePack: true },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧', isRtl: false, packId: 'pack_ar_en', hasOfflinePack: true },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷', isRtl: false, packId: 'pack_en_fr', hasOfflinePack: true },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸', isRtl: false, packId: 'pack_en_es', hasOfflinePack: true },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪', isRtl: false, hasOfflinePack: true },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹', isRtl: false, hasOfflinePack: true },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flag: '🇹🇷', isRtl: false, hasOfflinePack: true },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: '🇷🇺', isRtl: false, hasOfflinePack: false },
  { code: 'zh', name: 'Chinese', nativeName: '中文', flag: '🇨🇳', isRtl: false, hasOfflinePack: false },
];

export const AVAILABLE_PACKS: OfflineLanguagePack[] = [
  {
    id: 'pack_ar_en',
    name: 'العربية ↔ الإنجليزية (Arabic - English)',
    sourceLang: 'العربية',
    targetLang: 'English',
    sourceFlag: '🇸🇦',
    targetFlag: '🇬🇧',
    sizeMb: 5.4,
    vocabularyCount: 2600,
    isDownloaded: true,
    downloadProgress: 100,
    downloadDate: '2026-10-29',
  },
  {
    id: 'pack_en_fr',
    name: 'Français ↔ English (French - English)',
    sourceLang: 'Français',
    targetLang: 'English',
    sourceFlag: '🇫🇷',
    targetFlag: '🇬🇧',
    sizeMb: 4.8,
    vocabularyCount: 2200,
    isDownloaded: true,
    downloadProgress: 100,
    downloadDate: '2026-10-29',
  },
  {
    id: 'pack_en_es',
    name: 'Español ↔ English (Spanish - English)',
    sourceLang: 'Español',
    targetLang: 'English',
    sourceFlag: '🇪🇸',
    targetFlag: '🇬🇧',
    sizeMb: 4.2,
    vocabularyCount: 1950,
    isDownloaded: false,
    downloadProgress: 0,
  },
  {
    id: 'pack_de_en',
    name: 'Deutsch ↔ English (German - English)',
    sourceLang: 'Deutsch',
    targetLang: 'English',
    sourceFlag: '🇩🇪',
    targetFlag: '🇬🇧',
    sizeMb: 4.5,
    vocabularyCount: 2100,
    isDownloaded: false,
    downloadProgress: 0,
  },
  {
    id: 'pack_tr_ar',
    name: 'Türkçe ↔ العربية (Turkish - Arabic)',
    sourceLang: 'Türkçe',
    targetLang: 'العربية',
    sourceFlag: '🇹🇷',
    targetFlag: '🇸🇦',
    sizeMb: 4.0,
    vocabularyCount: 1800,
    isDownloaded: false,
    downloadProgress: 0,
  },
];

// Offline bidirectional phrasebook & vocabulary bank
export const OFFLINE_DICTIONARY: Record<string, OfflineTranslationEntry[]> = {
  pack_ar_en: [
    { sourceText: 'مرحباً', translatedText: 'Hello', pronunciation: 'heh-LOH', category: 'Greetings' },
    { sourceText: 'صباح الخير', translatedText: 'Good morning', pronunciation: 'good MOR-ning', category: 'Greetings' },
    { sourceText: 'مساء الخير', translatedText: 'Good evening', pronunciation: 'good EEV-ning', category: 'Greetings' },
    { sourceText: 'مع السلامة', translatedText: 'Goodbye', pronunciation: 'good-BYE', category: 'Greetings' },
    { sourceText: 'شكراً', translatedText: 'Thank you', pronunciation: 'THANK yoo', category: 'Polite' },
    { sourceText: 'شكراً جزيلاً', translatedText: 'Thank you very much', pronunciation: 'THANK yoo VEH-ree much', category: 'Polite' },
    { sourceText: 'من فضلك', translatedText: 'Please', pronunciation: 'PLEEZ', category: 'Polite' },
    { sourceText: 'عفواً', translatedText: "You're welcome", pronunciation: 'yoor WEL-kum', category: 'Polite' },
    { sourceText: 'آسف', translatedText: 'Sorry', pronunciation: 'SOR-ee', category: 'Polite' },
    { sourceText: 'نعم', translatedText: 'Yes', pronunciation: 'YES', category: 'Essentials' },
    { sourceText: 'لا', translatedText: 'No', pronunciation: 'NOH', category: 'Essentials' },
    { sourceText: 'كيف حالك؟', translatedText: 'How are you?', pronunciation: 'how ahr yoo', category: 'Conversation' },
    { sourceText: 'أنا بخير، شكراً', translatedText: "I am fine, thank you", pronunciation: 'eye am fyne, thank yoo', category: 'Conversation' },
    { sourceText: 'ما اسمك؟', translatedText: 'What is your name?', pronunciation: 'waht iz yoor naym', category: 'Conversation' },
    { sourceText: 'اسمي سارة', translatedText: 'My name is Sarah', pronunciation: 'my naym iz SEH-ruh', category: 'Conversation' },
    { sourceText: 'سررت بلقائك', translatedText: 'Nice to meet you', pronunciation: 'nyce too meet yoo', category: 'Conversation' },
    { sourceText: 'أين المطار؟', translatedText: 'Where is the airport?', pronunciation: 'wehr iz thee EHR-port', category: 'Travel' },
    { sourceText: 'أين الفندق؟', translatedText: 'Where is the hotel?', pronunciation: 'wehr iz thee hoh-TEL', category: 'Travel' },
    { sourceText: 'أحتاج إلى سيارة أجرة', translatedText: 'I need a taxi', pronunciation: 'eye need uh TAK-see', category: 'Travel' },
    { sourceText: 'محطة القطار', translatedText: 'Train station', pronunciation: 'trayn STAY-shun', category: 'Travel' },
    { sourceText: 'جواز السفر', translatedText: 'Passport', pronunciation: 'PASS-port', category: 'Travel' },
    { sourceText: 'تذكرة', translatedText: 'Ticket', pronunciation: 'TIK-it', category: 'Travel' },
    { sourceText: 'انعطف يميناً', translatedText: 'Turn right', pronunciation: 'turn ryte', category: 'Directions' },
    { sourceText: 'انعطف يساراً', translatedText: 'Turn left', pronunciation: 'turn left', category: 'Directions' },
    { sourceText: 'إلى الأمام مباشرة', translatedText: 'Straight ahead', pronunciation: 'strayt uh-HED', category: 'Directions' },
    { sourceText: 'أريد ماءً من فضلك', translatedText: 'I want water please', pronunciation: 'eye wahnt WAH-ter pleez', category: 'Dining' },
    { sourceText: 'قائمة الطعام من فضلك', translatedText: 'The menu please', pronunciation: 'thee MEN-yoo pleez', category: 'Dining' },
    { sourceText: 'الحساب من فضلك', translatedText: 'The bill please', pronunciation: 'thee bil pleez', category: 'Dining' },
    { sourceText: 'الطعام لذيذ', translatedText: 'The food is delicious', pronunciation: 'thee food iz dih-LISH-us', category: 'Dining' },
    { sourceText: 'ساعدني من فضلك', translatedText: 'Help me please', pronunciation: 'help mee pleez', category: 'Emergency' },
    { sourceText: 'أحتاج إلى طبيب', translatedText: 'I need a doctor', pronunciation: 'eye need uh DOK-ter', category: 'Emergency' },
    { sourceText: 'أين أقرب مستشفى؟', translatedText: 'Where is the nearest hospital?', pronunciation: 'wehr iz thee NEER-est HOS-pi-tul', category: 'Emergency' },
    { sourceText: 'أنا تائه', translatedText: 'I am lost', pronunciation: 'eye am lost', category: 'Emergency' },
    { sourceText: 'لدينا اجتماع اليوم', translatedText: 'We have a meeting today', pronunciation: 'wee hav uh MEE-ting too-DAY', category: 'Work' },
    { sourceText: 'المشروع جاهز', translatedText: 'The project is ready', pronunciation: 'thee PROH-jekt iz REH-dee', category: 'Work' },
    { sourceText: 'أرسل لي بريداً إلكترونياً', translatedText: 'Send me an email', pronunciation: 'send mee an EE-mayl', category: 'Work' },
    { sourceText: 'كم الساعة الآن؟', translatedText: 'What time is it now?', pronunciation: 'waht tyme iz it now', category: 'Time' },
    { sourceText: 'اليوم', translatedText: 'Today', pronunciation: 'too-DAY', category: 'Time' },
    { sourceText: 'غداً', translatedText: 'Tomorrow', pronunciation: 'tuh-MAH-roh', category: 'Time' },
    { sourceText: 'أمس', translatedText: 'Yesterday', pronunciation: 'YES-ter-day', category: 'Time' },
    { sourceText: 'بكم هذا؟', translatedText: 'How much is this?', pronunciation: 'how much iz this', category: 'Shopping' },
  ],
  pack_en_fr: [
    { sourceText: 'Bonjour', translatedText: 'Hello', pronunciation: 'bon-ZHOOR', category: 'Greetings' },
    { sourceText: 'Merci beaucoup', translatedText: 'Thank you very much', pronunciation: 'mair-SEE boh-KOO', category: 'Polite' },
    { sourceText: "S'il vous plaît", translatedText: 'Please', pronunciation: 'seel voo PLEH', category: 'Polite' },
    { sourceText: 'Au revoir', translatedText: 'Goodbye', pronunciation: 'oh ruh-VWAHR', category: 'Greetings' },
    { sourceText: 'Comment allez-vous ?', translatedText: 'How are you?', pronunciation: 'koh-mahn tah-lay VOO', category: 'Conversation' },
    { sourceText: 'Où est la gare ?', translatedText: 'Where is the train station?', pronunciation: 'oo ay lah GAHR', category: 'Travel' },
    { sourceText: "L'addition s'il vous plaît", translatedText: 'The check please', pronunciation: 'lah-dee-SYON seel voo pleh', category: 'Dining' },
    { sourceText: "J'ai besoin d'aide", translatedText: 'I need help', pronunciation: 'zhay buh-ZWAHN dayd', category: 'Emergency' },
  ],
  pack_en_es: [
    { sourceText: 'Hola', translatedText: 'Hello', pronunciation: 'OH-lah', category: 'Greetings' },
    { sourceText: 'Muchas gracias', translatedText: 'Thank you very much', pronunciation: 'MOO-chahs GRAH-syahs', category: 'Polite' },
    { sourceText: 'Por favor', translatedText: 'Please', pronunciation: 'por fah-VOR', category: 'Polite' },
    { sourceText: 'Adiós', translatedText: 'Goodbye', pronunciation: 'ah-DYOHS', category: 'Greetings' },
    { sourceText: '¿Cómo estás?', translatedText: 'How are you?', pronunciation: 'KOH-moh es-TAHS', category: 'Conversation' },
    { sourceText: '¿Dónde está el baño?', translatedText: 'Where is the bathroom?', pronunciation: 'DOHN-day es-TAH el BAHN-yoh', category: 'Travel' },
    { sourceText: 'La cuenta por favor', translatedText: 'The check please', pronunciation: 'lah KWEN-tah por fah-VOR', category: 'Dining' },
    { sourceText: 'Necesito un médico', translatedText: 'I need a doctor', pronunciation: 'neh-seh-SEE-toh oon MEH-dee-koh', category: 'Emergency' },
  ],
};

const WORD_MAP: Record<string, string> = {
  // Arabic to English
  'مرحبا': 'hello', 'مرحباً': 'hello', 'سلام': 'peace/hello', 'شكرا': 'thank you', 'شكراً': 'thank you',
  'نعم': 'yes', 'لا': 'no', 'أنا': 'I', 'انت': 'you', 'أنت': 'you', 'هو': 'he', 'هي': 'she', 'نحن': 'we',
  'صديق': 'friend', 'كتاب': 'book', 'قلم': 'pen', 'بيت': 'house', 'منزل': 'home', 'طعام': 'food',
  'ماء': 'water', 'شاي': 'tea', 'قهوة': 'coffee', 'سيارة': 'car', 'قطار': 'train', 'مطار': 'airport',
  'فندق': 'hotel', 'طبيب': 'doctor', 'مستشفى': 'hospital', 'كبير': 'big', 'صغير': 'small',
  'اليوم': 'today', 'غدا': 'tomorrow', 'غداً': 'tomorrow', 'أمس': 'yesterday',
  'أريد': 'I want', 'أحتاج': 'I need', 'أعمل': 'I work', 'أدرس': 'I study',
  // English to Arabic
  'hello': 'مرحباً', 'hi': 'أهلاً', 'goodbye': 'مع السلامة', 'bye': 'وداعاً', 'thanks': 'شكراً',
  'yes': 'نعم', 'no': 'لا', 'please': 'من فضلك', 'sorry': 'آسف', 'water': 'ماء', 'food': 'طعام',
  'coffee': 'قهوة', 'tea': 'شاي', 'house': 'منزل', 'car': 'سيارة', 'taxi': 'سيارة أجرة',
  'airport': 'مطار', 'hotel': 'فندق', 'doctor': 'طبيب', 'hospital': 'مستشفى', 'friend': 'صديق',
  'work': 'عمل', 'today': 'اليوم', 'tomorrow': 'غداً', 'yesterday': 'أمس',
};

class OfflineTranslationService {
  private packsKey = 'tolingo_offline_packs';
  private pinnedPairKey = 'tolingo_pinned_translation_pair';

  public getPacks(): OfflineLanguagePack[] {
    if (typeof window === 'undefined') return AVAILABLE_PACKS;
    try {
      const stored = localStorage.getItem(this.packsKey);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return AVAILABLE_PACKS;
  }

  public savePacks(packs: OfflineLanguagePack[]): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(this.packsKey, JSON.stringify(packs));
    } catch {
      // fallback
    }
  }

  public getPinnedPair(): { sourceLang: string; targetLang: string } {
    if (typeof window === 'undefined') return { sourceLang: 'ar', targetLang: 'en' };
    try {
      const stored = localStorage.getItem(this.pinnedPairKey);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return { sourceLang: 'ar', targetLang: 'en' };
  }

  public savePinnedPair(pair: { sourceLang: string; targetLang: string }): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(this.pinnedPairKey, JSON.stringify(pair));
    } catch {
      // fallback
    }
  }

  public translateOffline(text: string, sourceLang = 'ar', targetLang = 'en'): {
    translatedText: string;
    isExactMatch: boolean;
    pronunciation?: string;
    category?: string;
    confidence: number;
  } {
    const cleanText = text.trim();
    if (!cleanText) {
      return { translatedText: '', isExactMatch: false, confidence: 0 };
    }

    // Determine dictionary pack
    let packKey = 'pack_ar_en';
    if ((sourceLang === 'fr' && targetLang === 'en') || (sourceLang === 'en' && targetLang === 'fr')) {
      packKey = 'pack_en_fr';
    } else if ((sourceLang === 'es' && targetLang === 'en') || (sourceLang === 'en' && targetLang === 'es')) {
      packKey = 'pack_en_es';
    }

    const dict = OFFLINE_DICTIONARY[packKey] || OFFLINE_DICTIONARY.pack_ar_en;
    const lowerClean = cleanText.toLowerCase();

    // 1. Forward match
    const exactForward = dict.find(
      (entry) =>
        entry.sourceText.toLowerCase() === lowerClean ||
        entry.sourceText.replace(/[؟?.,!]/g, '').trim().toLowerCase() ===
          lowerClean.replace(/[؟?.,!]/g, '').trim()
    );
    if (exactForward) {
      return {
        translatedText: exactForward.translatedText,
        isExactMatch: true,
        pronunciation: exactForward.pronunciation,
        category: exactForward.category,
        confidence: 100,
      };
    }

    // 2. Reverse match
    const exactReverse = dict.find(
      (entry) =>
        entry.translatedText.toLowerCase() === lowerClean ||
        entry.translatedText.replace(/[؟?.,!]/g, '').trim().toLowerCase() ===
          lowerClean.replace(/[؟?.,!]/g, '').trim()
    );
    if (exactReverse) {
      return {
        translatedText: exactReverse.sourceText,
        isExactMatch: true,
        pronunciation: exactReverse.pronunciation,
        category: exactReverse.category,
        confidence: 100,
      };
    }

    // 3. Partial match
    const partialMatch = dict.find((entry) => {
      const src = entry.sourceText.toLowerCase();
      const trg = entry.translatedText.toLowerCase();
      return src.includes(lowerClean) || trg.includes(lowerClean);
    });
    if (partialMatch) {
      const isSrc = partialMatch.sourceText.toLowerCase().includes(lowerClean);
      return {
        translatedText: isSrc ? partialMatch.translatedText : partialMatch.sourceText,
        isExactMatch: false,
        pronunciation: partialMatch.pronunciation,
        category: partialMatch.category,
        confidence: 85,
      };
    }

    // 4. Tokenized fallback
    const tokens = cleanText.split(/\s+/);
    const translatedTokens: string[] = [];
    let foundCount = 0;

    for (const token of tokens) {
      const cleanToken = token.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?'"؛،!؟]/g, '').toLowerCase();
      if (WORD_MAP[cleanToken]) {
        translatedTokens.push(WORD_MAP[cleanToken]);
        foundCount++;
      } else {
        translatedTokens.push(token);
      }
    }

    const confidence = Math.round((foundCount / Math.max(1, tokens.length)) * 80);

    return {
      translatedText: translatedTokens.join(' '),
      isExactMatch: false,
      confidence: Math.max(confidence, 40),
    };
  }
}

export const offlineTranslationService = new OfflineTranslationService();
