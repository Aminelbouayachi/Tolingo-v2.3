/**
 * Tolingo Audio Service
 * Web Audio API synthesizer matching Android Kotlin AudioService:
 * - Crisp multi-harmonic victory chime (E5 -> C6 shimmer with C7 harmonic)
 * - Soft acoustic descending pop/thud for mistakes
 * - Milestone chest fanfare chords
 * - Text-to-speech with normal & slow playback
 */

class AudioService {
  private audioCtx: AudioContext | null = null;
  private soundEnabled = true;

  constructor() {
    // Initialized on first user interaction to comply with browser autoplay policies
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Synthesizes the delightful Duolingo-style harmonic bell chime:
   * Note 1: E5 (659.25 Hz) with 2nd harmonic
   * Note 2: C6 (1046.5 Hz) with C7 sparkle (2093 Hz) & E6 overtone (1318.5 Hz)
   */
  public playCorrectSound(): void {
    if (!this.soundEnabled) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;

      // Note 1 (E5: 659.25 Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, now);
      gain1.gain.setValueAtTime(0, now);
      gain1.gain.linearRampToValueAtTime(0.35, now + 0.008);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.12);

      // Note 2 (C6: 1046.50 Hz) starts at +85ms
      const t2 = now + 0.085;
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(1046.50, t2);
      gain2.gain.setValueAtTime(0, t2);
      gain2.gain.linearRampToValueAtTime(0.4, t2 + 0.008);
      gain2.gain.exponentialRampToValueAtTime(0.0001, t2 + 0.45);

      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(t2);
      osc2.stop(t2 + 0.45);

      // Sparkle overtone (C7: 2093 Hz)
      const osc3 = ctx.createOscillator();
      const gain3 = ctx.createGain();
      osc3.type = 'sine';
      osc3.frequency.setValueAtTime(2093.0, t2);
      gain3.gain.setValueAtTime(0, t2);
      gain3.gain.linearRampToValueAtTime(0.12, t2 + 0.005);
      gain3.gain.exponentialRampToValueAtTime(0.0001, t2 + 0.35);

      osc3.connect(gain3);
      gain3.connect(ctx.destination);
      osc3.start(t2);
      osc3.stop(t2 + 0.35);
    } catch {
      // Audio fallback silent
    }
  }

  /**
   * Synthesizes a soft acoustic thud/pop with a downward pitch bend
   */
  public playWrongSound(): void {
    if (!this.soundEnabled) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(240, now);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.22);

      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.22);
    } catch {
      // Audio fallback silent
    }
  }

  /**
   * Victory chest fanfare sound
   */
  public playChestRewardSound(): void {
    if (!this.soundEnabled) return;
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const chord = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      const now = ctx.currentTime;

      chord.forEach((freq, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const noteStart = now + index * 0.08;

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteStart);

        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.25, noteStart + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(noteStart);
        osc.stop(noteStart + 0.55);
      });
    } catch {
      // Audio fallback silent
    }
  }

  /**
   * Native Text-to-Speech playback using SpeechSynthesis
   */
  public speak(text: string, isSlow = false, lang = 'en-US'): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = isSlow ? 0.65 : 0.95;
      utterance.pitch = 1.05;

      const voices = window.speechSynthesis.getVoices();
      const englishVoice = voices.find(
        (v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.default)
      ) || voices.find((v) => v.lang.startsWith('en'));

      if (englishVoice) {
        utterance.voice = englishVoice;
      }

      window.speechSynthesis.speak(utterance);
    } catch {
      // TTS fallback silent
    }
  }
}

export const audioService = new AudioService();
