import React from 'react';
import { Star, Check, Lock, Trophy, Headphones, Dumbbell, Video } from 'lucide-react';
import { LessonModel, LessonNodeType } from '../types';

interface OctagonNodeProps {
  lesson: LessonModel;
  isActive: boolean;
  lessonIndex: number;
  totalLessonsInUnit?: number;
  onClick: () => void;
  onLockedClick?: () => void;
}

export const OctagonNode: React.FC<OctagonNodeProps> = ({
  lesson,
  isActive,
  lessonIndex,
  totalLessonsInUnit = 5,
  onClick,
  onLockedClick,
}) => {
  const isCompleted = lesson.isCompleted;
  const isLocked = lesson.isLocked;
  const isExam = lesson.isExam;

  // Render the specific icon or lesson number inside the octagon
  const renderContent = () => {
    if (isCompleted) {
      return <Check className="w-7 h-7 stroke-[3.5] text-white drop-shadow" />;
    }
    if (isLocked) {
      return <Lock className="w-5 h-5 text-stone-500" />;
    }
    if (isExam) {
      return <Trophy className="w-7 h-7 text-[#FFD700] fill-[#FFD700] drop-shadow" />;
    }

    // Active or in-progress: Shows the lesson number reached!
    return (
      <div className="flex flex-col items-center justify-center leading-none">
        <span className="text-xl font-black text-white font-['Nunito',sans-serif] tracking-tight">
          {lesson.lessonNumber}
        </span>
        <span className="text-[9px] font-extrabold text-white/80 font-['Nunito',sans-serif]">
          /{totalLessonsInUnit}
        </span>
      </div>
    );
  };

  return (
    <div className="relative flex flex-col items-center">
      {/* Star on top of the Octagon (كما طلب المستخدم: على شكل نجمة فوق وحد الشكل ثماني) */}
      <div
        className={`absolute -top-3 z-20 flex items-center justify-center transition-all duration-300 ${
          isActive
            ? 'scale-110 -translate-y-1'
            : isCompleted
            ? 'scale-100'
            : 'opacity-60 scale-90'
        }`}
      >
        <div className="relative">
          <Star
            className={`w-6 h-6 stroke-[2] drop-shadow-md ${
              isCompleted
                ? 'text-[#FFD700] fill-[#FFD700]'
                : isActive
                ? 'text-[#FFC857] fill-[#FFC857] animate-bounce'
                : 'text-stone-500 fill-stone-600'
            }`}
          />
        </div>
      </div>

      {/* Floating active label */}
      {isActive && (
        <div className="absolute -top-8 z-30 pointer-events-none">
          <span className="px-2.5 py-0.5 rounded-lg bg-white text-[#58CC02] text-[10px] font-black tracking-wider uppercase shadow-md border border-[#58CC02]">
            ابدأ الآن
          </span>
        </div>
      )}

      {/* 3D Octagon Button */}
      <div className="relative mt-2">
        {/* Octagon 3D Bottom Edge */}
        <div
          className={`absolute inset-0 top-1.5 w-16 h-16 transition-colors ${
            isCompleted
              ? 'bg-[#CC8800]'
              : isActive
              ? isExam
                ? 'bg-[#CC8800]'
                : 'bg-[#46A302]'
              : 'bg-[#1C282F]'
          }`}
          style={{
            clipPath:
              'polygon(29.3% 0%, 70.7% 0%, 100% 29.3%, 100% 70.7%, 70.7% 100%, 29.3% 100%, 0% 70.7%, 0% 29.3%)',
          }}
        />

        {/* Octagon 3D Top Surface */}
        <button
          onClick={() => {
            if (!isLocked) {
              onClick();
            } else if (onLockedClick) {
              onLockedClick();
            }
          }}
          className={`relative w-16 h-16 flex items-center justify-center transition-all duration-150 active:translate-y-1 cursor-pointer ${
            isCompleted
              ? 'bg-[#FFC857] hover:bg-[#ffbe3b] text-amber-950 shadow-md'
              : isActive
              ? isExam
                ? 'bg-[#FFC857] text-amber-950 ring-2 ring-[#FFC857]/50 shadow-xl'
                : 'bg-[#58CC02] hover:bg-[#62e302] text-white ring-2 ring-[#58CC02]/50 shadow-xl'
              : 'bg-[#2A3A42] hover:bg-[#32454f] text-stone-400'
          }`}
          style={{
            clipPath:
              'polygon(29.3% 0%, 70.7% 0%, 100% 29.3%, 100% 70.7%, 70.7% 100%, 29.3% 100%, 0% 70.7%, 0% 29.3%)',
          }}
          title={lesson.title}
        >
          {renderContent()}
        </button>
      </div>

      {/* Node subtitle */}
      <span
        className={`mt-1.5 text-[11px] font-bold text-center max-w-[120px] leading-tight line-clamp-1 ${
          isActive
            ? 'text-white'
            : isCompleted
            ? 'text-[#FFC857]'
            : 'text-stone-500'
        }`}
      >
        {lesson.title}
      </span>
    </div>
  );
};
