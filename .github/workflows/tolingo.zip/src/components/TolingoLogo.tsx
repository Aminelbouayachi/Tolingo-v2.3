import React from 'react';

interface TolingoLogoProps {
  size?: number;
  showText?: boolean;
  className?: string;
}

export const TolingoLogo: React.FC<TolingoLogoProps> = ({
  size = 48,
  showText = false,
  className = '',
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      <svg
        viewBox="0 0 320 360"
        width={size}
        height={(size * 360) / 320}
        className="shrink-0 drop-shadow-md select-none transition-transform hover:scale-105"
      >
        <defs>
          <filter id="tolingoShadow" x="-15%" y="-15%" width="130%" height="130%">
            <feDropShadow dx="0" dy="6" stdDeviation="10" floodColor="#000000" floodOpacity="0.25" />
          </filter>
        </defs>
        {/* Speech Bubble */}
        <g filter="url(#tolingoShadow)">
          <path
            fill="#F26B3A"
            d="M 90 28 C 42 28, 20 50, 20 98 L 20 172 C 20 220, 42 242, 90 242 L 100 242 L 70 292 L 132 242 L 230 242 C 278 242, 300 220, 300 172 L 300 98 C 300 50, 278 28, 230 28 Z"
          />
          {/* Rounded Bold Letter T */}
          <rect x="86" y="66" width="148" height="34" rx="17" fill="#FFFFFF" />
          <rect x="143" y="66" width="34" height="114" rx="17" fill="#FFFFFF" />
          {/* Golden Yellow Dot beside the stem */}
          <circle cx="214" cy="155" r="19" fill="#FFC857" />
        </g>
      </svg>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className="font-extrabold text-2xl tracking-wide text-[#F26B3A] font-['Nunito',sans-serif]">
            Tolingo
          </span>
          <span className="text-xs text-stone-400 font-semibold font-['Tajawal',sans-serif]">
            تعلم بالتحدث
          </span>
        </div>
      )}
    </div>
  );
};
