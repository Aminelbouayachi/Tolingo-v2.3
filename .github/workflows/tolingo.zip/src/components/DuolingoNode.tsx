import React from 'react';
import { Star, Video, Headphones, Lock, Check } from 'lucide-react';
import { LessonModel, LessonNodeType } from '../types';

interface DuolingoNodeProps {
  lesson: LessonModel;
  isActive: boolean;
  onClick: () => void;
  onLockedClick?: () => void;
}

export const DuolingoNode: React.FC<DuolingoNodeProps> = ({
  lesson,
  isActive,
  onClick,
  onLockedClick,
}) => {
  const isCompleted = lesson.isCompleted;
  const isLocked = lesson.isLocked;

  // Icon inside node
  const renderIcon = () => {
    if (lesson.nodeType === 'STORY') {
      return (
        <Video
          className={`w-7 h-7 ${
            isLocked ? 'text-[#3E525C]' : 'text-white fill-white'
          }`}
        />
      );
    }
    if (lesson.nodeType === 'LISTENING') {
      return (
        <Headphones
          className={`w-7 h-7 ${
            isLocked ? 'text-[#3E525C]' : 'text-white'
          }`}
        />
      );
    }
    // Standard Star node
    return (
      <Star
        className={`w-8 h-8 ${
          isLocked
            ? 'text-[#3E525C] fill-[#3E525C]'
            : 'text-white fill-white drop-shadow-sm'
        }`}
      />
    );
  };

  return (
    <div className="relative flex flex-col items-center select-none">
      {/* 1. ACTIVE NODE WITH SEGMENTED ARCS & ELECTRIC LIGHTNING BOLT (مطابق للصورة تماماً) */}
      {isActive ? (
        <div className="relative w-24 h-24 flex items-center justify-center">
          {/* Segmented Circular Progress Arc around Active Node */}
          <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 100 100">
            {/* Segment 1 */}
            <circle
              cx="50"
              cy="50"
              r="44"
              fill="none"
              stroke="#58CC02"
              strokeWidth="5"
              strokeDasharray="42 6"
              strokeLinecap="round"
              className="drop-shadow-sm"
            />
            {/* Segment 2 */}
            <circle
              cx="50"
              cy="50"
              r="44"
              fill="none"
              stroke="#58CC02"
              strokeWidth="5"
              strokeDasharray="30 8"
              strokeDashoffset="-50"
              strokeLinecap="round"
            />
            {/* Dark inactive segment */}
            <circle
              cx="50"
              cy="50"
              r="44"
              fill="none"
              stroke="#2A3A42"
              strokeWidth="5"
              strokeDasharray="30 8"
              strokeDashoffset="-90"
              strokeLinecap="round"
            />
          </svg>

          {/* 3D Active Green Circle */}
          <div className="relative w-[70px] h-[70px]">
            {/* 3D bottom bevel shadow */}
            <div className="absolute inset-0 top-2.5 w-[70px] h-[70px] rounded-full bg-[#46A302]" />

            {/* Top vibrant glossy surface */}
            <button
              onClick={onClick}
              className="relative w-[70px] h-[70px] rounded-full bg-[#58CC02] hover:bg-[#62e302] flex items-center justify-center shadow-lg active:translate-y-1 transition-transform cursor-pointer overflow-hidden group"
            >
              {/* Electric Lightning Bolt Crack (كما في لقطة الشاشة 2 و 3!) */}
              <svg
                viewBox="0 0 100 100"
                className="absolute inset-0 w-full h-full pointer-events-none opacity-90 animate-pulse"
              >
                <path
                  d="M 38 12 L 52 46 L 36 50 L 62 88"
                  fill="none"
                  stroke="#A7F3D0"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  filter="drop-shadow(0 0 4px #FFFFFF)"
                />
              </svg>

              {/* Star inside */}
              <Star className="w-8 h-8 text-white fill-white drop-shadow-md relative z-10" />
            </button>
          </div>
        </div>
      ) : isCompleted ? (
        /* 2. COMPLETED 3D GREEN NODE */
        <div className="relative w-[68px] h-[78px] flex items-center justify-center">
          {/* Bottom bevel */}
          <div className="absolute inset-0 top-2 w-[68px] h-[68px] rounded-full bg-[#46A302]" />
          {/* Top surface */}
          <button
            onClick={onClick}
            className="relative w-[68px] h-[68px] rounded-full bg-[#58CC02] hover:bg-[#62e302] flex items-center justify-center shadow-md active:translate-y-1 transition-transform cursor-pointer"
          >
            {renderIcon()}
          </button>
        </div>
      ) : (
        /* 3. LOCKED 3D DARK SLATE NODE */
        <div className="relative w-[68px] h-[78px] flex items-center justify-center">
          {/* Bottom bevel */}
          <div className="absolute inset-0 top-2 w-[68px] h-[68px] rounded-full bg-[#182329]" />
          {/* Top surface */}
          <button
            onClick={onLockedClick || onClick}
            className="relative w-[68px] h-[68px] rounded-full bg-[#24333B] hover:bg-[#2c3d47] flex items-center justify-center shadow-inner active:translate-y-1 transition-transform cursor-pointer"
          >
            {renderIcon()}
          </button>
        </div>
      )}
    </div>
  );
};

/**
 * Wooden Treasure Chest on the path matching the exact asset in screenshot
 */
export const WoodenTreasureChest: React.FC<{
  isClaimed: boolean;
  onClick: () => void;
}> = ({ isClaimed, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`relative w-20 h-20 transition-transform active:scale-95 cursor-pointer ${
        isClaimed ? 'opacity-50 grayscale' : 'hover:scale-105 animate-bounce'
      }`}
      title="صندوق الكنز"
    >
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-lg">
        {/* Lid Top */}
        <rect x="18" y="24" width="64" height="20" rx="6" fill="#D97706" />
        <rect x="14" y="32" width="72" height="12" rx="4" fill="#FDE68A" />
        <rect x="22" y="26" width="56" height="6" rx="2" fill="#B45309" />

        {/* Chest Base */}
        <rect x="18" y="44" width="64" height="42" rx="6" fill="#D97706" />
        {/* Metal corners */}
        <rect x="18" y="44" width="10" height="42" fill="#FDE68A" />
        <rect x="72" y="44" width="10" height="42" fill="#FDE68A" />
        {/* Wooden Horizontal Planks */}
        <rect x="28" y="58" width="44" height="4" fill="#B45309" />
        <rect x="28" y="74" width="44" height="4" fill="#B45309" />

        {/* Central Round Clasp */}
        <circle cx="50" cy="46" r="9" fill="#F3F4F6" stroke="#9CA3AF" strokeWidth="2" />
        <circle cx="50" cy="46" r="4" fill="#6B7280" />
      </svg>
    </div>
  );
};

/**
 * Sleeping Mascot Watermark on the path (matching the owl silhouette in screenshot)
 */
export const SleepingMascotWatermark: React.FC = () => {
  return (
    <div className="absolute left-6 pointer-events-none opacity-25 select-none flex flex-col items-center">
      {/* Sleeping mascot illustration */}
      <div className="w-24 h-24 relative">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Owl/Fox Body */}
          <ellipse cx="50" cy="55" rx="34" ry="28" fill="#3E525C" />
          {/* Sleeping closed eyes */}
          <path d="M 32 50 Q 40 58 48 50" fill="none" stroke="#24333B" strokeWidth="3" strokeLinecap="round" />
          <path d="M 52 50 Q 60 58 68 50" fill="none" stroke="#24333B" strokeWidth="3" strokeLinecap="round" />
          {/* Beak/Snout */}
          <polygon points="46,55 54,55 50,62" fill="#24333B" />
          {/* Feathers / Zzz flowers */}
          <circle cx="20" cy="44" r="5" fill="#3E525C" />
          <circle cx="80" cy="44" r="5" fill="#3E525C" />
        </svg>
      </div>

      {/* 3 Stars underneath */}
      <div className="flex gap-2 text-stone-600 -mt-2">
        <Star className="w-4 h-4 fill-current" />
        <Star className="w-4 h-4 fill-current" />
        <Star className="w-4 h-4 fill-current" />
      </div>
    </div>
  );
};
