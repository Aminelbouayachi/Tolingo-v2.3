import React from 'react';
import { Zap, Gem, Flame, Globe } from 'lucide-react';
import { UserProfile, Course, AppLanguageCode, SUPPORTED_LANGUAGES } from '../types';
import { LocalizedStrings } from '../localization/strings';

interface TopStatsBarProps {
  userProfile: UserProfile;
  course: Course;
  strings: LocalizedStrings;
  onOpenHeartRefill: () => void;
  onOpenGitSync: () => void;
  onChangeLanguage: (lang: AppLanguageCode) => void;
}

export const TopStatsBar: React.FC<TopStatsBarProps> = ({
  userProfile,
  course,
  strings,
  onOpenHeartRefill,
  onOpenGitSync,
  onChangeLanguage,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#131F24] border-b border-[#203038] px-4 py-2 select-none">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* 1. Energy / Hearts (Pink Badge matching Screenshot: 25 ⚡) */}
        <button
          onClick={onOpenHeartRefill}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-transparent hover:bg-[#1C2B32] transition-colors cursor-pointer"
        >
          <span className="font-black text-sm text-[#FF5B89] font-['Nunito',sans-serif]">
            {userProfile.hearts * 5}
          </span>
          <div className="w-5 h-5 rounded-md bg-[#FF5B89] flex items-center justify-center text-white shadow-sm">
            <Zap className="w-3.5 h-3.5 fill-current" />
          </div>
        </button>

        {/* 2. Gems (Cyan Blue Badge matching Screenshot: 179 💎) */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-transparent hover:bg-[#1C2B32] transition-colors">
          <span className="font-black text-sm text-[#1CB0F6] font-['Nunito',sans-serif]">
            {userProfile.gems}
          </span>
          <div className="w-5 h-5 rounded-md bg-[#1CB0F6] flex items-center justify-center text-white shadow-sm">
            <Gem className="w-3.5 h-3.5 fill-current" />
          </div>
        </div>

        {/* 3. Streak Flame (matching Screenshot: 6 🔥) */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-transparent hover:bg-[#1C2B32] transition-colors">
          <span className="font-black text-sm text-[#FF9600] font-['Nunito',sans-serif]">
            {userProfile.streakDays}
          </span>
          <Flame className="w-5 h-5 text-[#FF9600] fill-[#FF9600]" />
        </div>

        {/* 4. Flag & Course Level (matching Screenshot: 11 🇺🇸) */}
        <div className="relative group">
          <button className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-transparent hover:bg-[#1C2B32] transition-colors cursor-pointer">
            <span className="font-black text-sm text-stone-200 font-['Nunito',sans-serif]">
              {userProfile.completedLessonsCount}
            </span>
            <span className="text-xl leading-none">🇺🇸</span>
          </button>

          {/* Language dropdown */}
          <div className="absolute end-0 mt-1 hidden group-hover:flex flex-col bg-[#1C2B32] border border-[#2A3A42] rounded-xl shadow-xl p-1 z-50 min-w-[130px]">
            {(['ar', 'fr', 'en'] as AppLanguageCode[]).map((code) => (
              <button
                key={code}
                onClick={() => onChangeLanguage(code)}
                className={`flex items-center gap-2 px-3 py-2 text-xs font-bold rounded-lg text-start transition-colors cursor-pointer ${
                  userProfile.nativeLanguage === code
                    ? 'bg-[#58CC02] text-white'
                    : 'text-stone-300 hover:bg-[#2A3A42]'
                }`}
              >
                <span className="text-base">{SUPPORTED_LANGUAGES[code].flag}</span>
                <span>{SUPPORTED_LANGUAGES[code].displayName}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 5. Direct APK Download button */}
        <a
          href="/Tolingo.apk"
          download="Tolingo.apk"
          title="تحميل ملف Tolingo.apk مباشرة"
          className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-[#58CC02] hover:bg-[#46A302] text-black text-xs font-black shadow-[0_2px_0_#46A302] active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
        >
          <span className="text-xs">📥</span>
          <span className="font-black">APK</span>
        </a>

      </div>
    </header>
  );
};
