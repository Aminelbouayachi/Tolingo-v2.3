import React from 'react';
import { Heart, Gem, Dumbbell, X } from 'lucide-react';
import { UserProfile } from '../types';
import { LocalizedStrings } from '../localization/strings';

interface HeartRefillDialogProps {
  userProfile: UserProfile;
  strings: LocalizedStrings;
  onDismiss: () => void;
  onRefillWithGems: () => void;
  onPracticeToEarnHeart: () => void;
}

export const HeartRefillDialog: React.FC<HeartRefillDialogProps> = ({
  userProfile,
  strings,
  onDismiss,
  onRefillWithGems,
  onPracticeToEarnHeart,
}) => {
  const canAffordGems = userProfile.gems >= 50;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-sm bg-[#1C2B32] border-2 border-[#2A3A42] rounded-3xl p-6 shadow-2xl text-center">
        {/* Close Button */}
        <button
          onClick={onDismiss}
          className="absolute top-4 end-4 text-stone-400 hover:text-white p-1 rounded-full bg-[#131F24] border border-[#2A3A42] cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Big Heart Icon */}
        <div className="w-20 h-20 mx-auto mb-4 rounded-3xl bg-[#FF4B4B]/15 border-2 border-[#FF4B4B]/40 flex items-center justify-center animate-pulse">
          <Heart className="w-12 h-12 text-[#FF4B4B] fill-[#FF4B4B]" />
        </div>

        <h3 className="text-2xl font-black text-white mb-2 font-['Tajawal','Nunito',sans-serif]">
          {strings.refillHearts}
        </h3>
        <p className="text-sm text-stone-300 mb-6 leading-relaxed">
          {userProfile.hearts === 0 ? strings.outOfHearts : `${userProfile.hearts} / ${userProfile.maxHearts} ${strings.hearts}`}
        </p>

        {/* Option 1: Refill with Gems */}
        <button
          onClick={onRefillWithGems}
          disabled={!canAffordGems}
          className={`w-full py-3.5 px-4 mb-3 rounded-2xl font-black text-sm flex items-center justify-center gap-2 border-b-4 transition-all ${
            canAffordGems
              ? 'bg-[#1CB0F6] hover:bg-[#189cdb] border-[#1479ab] text-white active:translate-y-1 active:border-b-0 cursor-pointer shadow-lg'
              : 'bg-stone-700 border-stone-800 text-stone-400 cursor-not-allowed opacity-60'
          }`}
        >
          <Gem className="w-5 h-5 fill-current" />
          <span>{strings.refillWithGems}</span>
        </button>

        {/* Option 2: Practice mistakes */}
        <button
          onClick={onPracticeToEarnHeart}
          className="w-full py-3 px-4 rounded-2xl font-bold text-sm bg-[#2A3A42] hover:bg-[#344650] border-b-4 border-[#1E2B31] text-stone-200 hover:text-white flex items-center justify-center gap-2 active:translate-y-1 active:border-b-0 cursor-pointer transition-all"
        >
          <Dumbbell className="w-5 h-5 text-[#58CC02]" />
          <span>{strings.practiceToRefill}</span>
        </button>

        {/* Timer note */}
        <p className="mt-4 text-xs text-stone-400">
          {strings.nextHeartIn} <span className="font-bold text-[#FF9600]">15:00</span>
        </p>
      </div>
    </div>
  );
};
