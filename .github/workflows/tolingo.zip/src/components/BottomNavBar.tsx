import React from 'react';
import { NavDestination } from '../types';
import { LocalizedStrings } from '../localization/strings';

interface BottomNavBarProps {
  currentTab: NavDestination;
  onSelectTab: (tab: NavDestination) => void;
  mistakesCount: number;
  strings: LocalizedStrings;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentTab,
  onSelectTab,
  mistakesCount,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#131F24] border-t border-[#203038] px-3 py-2 select-none">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* 1. Feed / Stories (Purple Chat Bubble with notification dot) */}
        <button
          onClick={() => onSelectTab('MISTAKES')}
          className="relative p-2 text-stone-400 hover:text-white transition-transform active:scale-90 cursor-pointer"
          title="Stories & Feed"
        >
          <div className="w-8 h-8 rounded-full bg-[#A855F7]/20 flex items-center justify-center text-lg">
            💬
          </div>
          <span className="absolute top-1 start-1 w-2.5 h-2.5 rounded-full bg-[#FF4B4B] border-2 border-[#131F24]" />
        </button>

        {/* 2. Offline Translator / Practice Mascot (Cyan Sparkle) */}
        <button
          onClick={() => onSelectTab('TRANSLATE')}
          className={`relative p-2 transition-transform active:scale-90 cursor-pointer ${
            currentTab === 'TRANSLATE' ? 'scale-110' : 'text-stone-400 hover:text-white'
          }`}
          title="Offline Translator"
        >
          <div className="w-8 h-8 rounded-full bg-[#1CB0F6]/20 border border-[#1CB0F6]/40 flex items-center justify-center text-lg">
            🌐
          </div>
          <span className="absolute top-1 start-1 w-2 h-2 rounded-full bg-[#58CC02]" />
        </button>

        {/* 3. Hearts & Mistakes (Pink Heart with notification badge) */}
        <button
          onClick={() => onSelectTab('MISTAKES')}
          className={`relative p-2 transition-transform active:scale-90 cursor-pointer ${
            currentTab === 'MISTAKES' ? 'scale-110' : 'text-stone-400 hover:text-white'
          }`}
          title="Practice & Hearts"
        >
          <div className="w-8 h-8 rounded-full bg-[#FF5B89]/20 flex items-center justify-center text-lg">
            💖
          </div>
          {mistakesCount > 0 && (
            <span className="absolute top-1 start-1 w-2.5 h-2.5 rounded-full bg-[#FF4B4B] border-2 border-[#131F24]" />
          )}
        </button>

        {/* 4. Leaderboards (Golden Trophy) */}
        <button
          onClick={() => onSelectTab('LEADERBOARD')}
          className={`relative p-2 transition-transform active:scale-90 cursor-pointer ${
            currentTab === 'LEADERBOARD' ? 'scale-110' : 'text-stone-400 hover:text-white'
          }`}
          title="Leaderboard"
        >
          <div className="w-8 h-8 rounded-full bg-[#FF9600]/20 flex items-center justify-center text-lg">
            🏆
          </div>
          <span className="absolute top-1 start-1 w-2.5 h-2.5 rounded-full bg-[#FF4B4B] border-2 border-[#131F24]" />
        </button>

        {/* 5. Profile & Settings */}
        <button
          onClick={() => onSelectTab('PROFILE')}
          className={`relative p-2 transition-transform active:scale-90 cursor-pointer ${
            currentTab === 'PROFILE' ? 'scale-110' : 'text-stone-400 hover:text-white'
          }`}
          title="Profile"
        >
          <div className="w-8 h-8 rounded-full bg-[#FFC857]/20 flex items-center justify-center text-lg">
            👤
          </div>
          <span className="absolute top-1 start-1 w-2.5 h-2.5 rounded-full bg-[#FF4B4B] border-2 border-[#131F24]" />
        </button>

        {/* 6. Home / Learn Path (The Active Pill from Screenshot!) */}
        <button
          onClick={() => onSelectTab('LEARN')}
          className={`relative p-1.5 rounded-2xl border-2 transition-all active:scale-95 cursor-pointer ${
            currentTab === 'LEARN'
              ? 'bg-[#1C2B32] border-[#2A3A42] ring-2 ring-[#1CB0F6]/40'
              : 'border-transparent text-stone-400 hover:text-white'
          }`}
          title="Home"
        >
          <div className="w-9 h-8 flex items-center justify-center">
            {/* House icon with golden roof */}
            <svg viewBox="0 0 32 32" className="w-7 h-7 drop-shadow-sm">
              <path
                d="M 16 4 L 4 15 L 7 15 L 7 28 L 25 28 L 25 15 L 28 15 Z"
                fill="#FFC857"
              />
              <path
                d="M 10 16 L 22 16 L 22 28 L 10 28 Z"
                fill="#F26B3A"
              />
              <circle cx="16" cy="22" r="3" fill="#FFFFFF" />
            </svg>
          </div>
        </button>
      </div>
    </nav>
  );
};
