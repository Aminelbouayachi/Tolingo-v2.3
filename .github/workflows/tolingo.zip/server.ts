import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Direct APK Download Routes
app.get(['/Tolingo.apk', '/download', '/download-apk'], (_req: Request, res: Response) => {
  const apkPath = path.resolve(__dirname, 'public', 'Tolingo.apk');
  res.download(apkPath, 'Tolingo.apk', (err) => {
    if (err) {
      res.status(404).send('APK file not found or still processing.');
    }
  });
});

const REPO_DIR = '/tmp/tolingo';
const GITHUB_TOKEN = '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';
const REPO_URL = `https://${GITHUB_TOKEN}@github.com/Aminelbouayachi/Tolingo-v1.git`;

// Git Status Route
app.get('/api/git/status', async (req: Request, res: Response) => {
  try {
    const { stdout: logOut } = await execPromise(
      `git -C "${REPO_DIR}" log -n 5 --pretty=format:'{"hash":"%h","message":"%s","date":"%cd"}' --date=short`
    );
    const { stdout: branchOut } = await execPromise(`git -C "${REPO_DIR}" branch --show-current`);
    const { stdout: statusOut } = await execPromise(`git -C "${REPO_DIR}" status --porcelain`);

    const commits = logOut
      .trim()
      .split('\n')
      .filter(Boolean)
      .map((line) => {
        try {
          return JSON.parse(line);
        } catch {
          return { hash: 'commit', message: line };
        }
      });

    res.json({
      success: true,
      branch: branchOut.trim() || 'main',
      modified: statusOut.trim().split('\n').filter(Boolean),
      commits,
    });
  } catch (err: unknown) {
    res.json({
      success: false,
      branch: 'main',
      commits: [
        { hash: '6423134', message: 'fix: cancel button text in HomeScreen' },
        { hash: '2fea5ae', message: 'feat(v1.3): Duolingo path UI with Section 2 Unit 6' },
      ],
      error: (err as Error).message,
    });
  }
});

// Git Push Route
app.post('/api/git/push', async (req: Request, res: Response) => {
  try {
    const message = req.body?.message || 'feat: update Tolingo applet';

    await execPromise(`git -C "${REPO_DIR}" config user.name "Amine Elbouayachi"`);
    await execPromise(`git -C "${REPO_DIR}" config user.email "locoaminn@gmail.com"`);
    await execPromise(`git -C "${REPO_DIR}" remote set-url origin "${REPO_URL}"`);
    await execPromise(`git -C "${REPO_DIR}" add .`);

    try {
      await execPromise(`git -C "${REPO_DIR}" commit -m "${message.replace(/"/g, '\\"')}"`);
    } catch {
      // Nothing to commit
    }

    await execPromise(`git -C "${REPO_DIR}" push origin main`);

    const { stdout: logOut } = await execPromise(
      `git -C "${REPO_DIR}" log -n 5 --pretty=format:'{"hash":"%h","message":"%s"}'`
    );
    const commits = logOut
      .trim()
      .split('\n')
      .filter(Boolean)
      .map((line) => {
        try {
          return JSON.parse(line);
        } catch {
          return { hash: 'commit', message: line };
        }
      });

    res.json({ success: true, message: 'Pushed to GitHub successfully!', commits });
  } catch (err: unknown) {
    res.status(500).json({ success: false, error: (err as Error).message });
  }
});

// Setup Vite middlewares in development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Tolingo server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
